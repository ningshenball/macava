import { Authenticated, Unauthenticated, useQuery } from "convex/react";
import { api } from "../convex/_generated/api";
import { SignInForm } from "./SignInForm";
import { SignOutButton } from "./SignOutButton";
import { Toaster } from "sonner";
import { useState, useEffect } from "react";
import { Navigation } from "./components/Navigation";
import { Home } from "./components/Home";
import { Languages } from "./components/Languages";
import { Progress } from "./components/Progress";
import { LessonView } from "./components/LessonView";
import { MacaChat } from "./components/MacaChat";
import { AIProviderInfo } from "./components/AIProviderInfo";

type Page = "home" | "languages" | "progress" | "lesson";

export default function App() {
  const [currentPage, setCurrentPage] = useState<Page>("home");
  const [currentLesson, setCurrentLesson] = useState<{language: string, lessonId: string} | null>(null);
  const [darkMode, setDarkMode] = useState(() => {
    if (typeof window !== "undefined") {
      return window.matchMedia("(prefers-color-scheme: dark)").matches;
    }
    return false;
  });

  useEffect(() => {
    const mediaQuery = window.matchMedia("(prefers-color-scheme: dark)");
    const handleChange = (e: MediaQueryListEvent) => setDarkMode(e.matches);
    mediaQuery.addEventListener("change", handleChange);
    return () => mediaQuery.removeEventListener("change", handleChange);
  }, []);

  useEffect(() => {
    document.documentElement.classList.toggle("dark", darkMode);
  }, [darkMode]);

  const startLesson = (language: string, lessonId: string) => {
    setCurrentLesson({ language, lessonId });
    setCurrentPage("lesson");
  };

  const goHome = () => {
    setCurrentPage("home");
    setCurrentLesson(null);
  };

  return (
    <div className={`min-h-screen transition-colors duration-300 ${
      darkMode ? "dark bg-gray-900" : "bg-gradient-to-br from-blue-50 to-green-50"
    }`}>
      <Navigation 
        currentPage={currentPage}
        setCurrentPage={setCurrentPage}
        darkMode={darkMode}
        setDarkMode={setDarkMode}
        goHome={goHome}
      />
      
      <main className="pt-16">
        <Content 
          currentPage={currentPage}
          currentLesson={currentLesson}
          startLesson={startLesson}
          goHome={goHome}
        />
      </main>
      
      <Authenticated>
        <MacaChat />
        <AIProviderInfo />
      </Authenticated>
      
      <Toaster />
    </div>
  );
}

function Content({ 
  currentPage, 
  currentLesson, 
  startLesson, 
  goHome 
}: {
  currentPage: Page;
  currentLesson: {language: string, lessonId: string} | null;
  startLesson: (language: string, lessonId: string) => void;
  goHome: () => void;
}) {
  const loggedInUser = useQuery(api.auth.loggedInUser);

  if (loggedInUser === undefined) {
    return (
      <div className="flex justify-center items-center min-h-[50vh]">
        <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-blue-500"></div>
      </div>
    );
  }

  return (
    <div className="container mx-auto px-4 py-8">
      <Unauthenticated>
        <div className="max-w-md mx-auto">
          <div className="text-center mb-8">
            <h1 className="text-4xl font-bold text-gray-800 dark:text-white mb-4">
              Welcome to Macava.io! ^_^
            </h1>
            <p className="text-xl text-gray-600 dark:text-gray-300">
              Your fun coding study buddy awaits!
            </p>
          </div>
          <SignInForm />
        </div>
      </Unauthenticated>

      <Authenticated>
        {currentPage === "home" && <Home startLesson={startLesson} />}
        {currentPage === "languages" && <Languages startLesson={startLesson} />}
        {currentPage === "progress" && <Progress />}
        {currentPage === "lesson" && currentLesson && (
          <LessonView 
            language={currentLesson.language}
            lessonId={currentLesson.lessonId}
            goHome={goHome}
          />
        )}
      </Authenticated>
    </div>
  );
}
