import { useState } from "react";

interface Question {
  question: string;
  options: string[];
  correct: number;
}

interface QuizProps {
  questions: Question[];
  onComplete: (score: number) => void;
  currentScore: number | null;
}

export function Quiz({ questions, onComplete, currentScore }: QuizProps) {
  const [currentQuestion, setCurrentQuestion] = useState(0);
  const [selectedAnswer, setSelectedAnswer] = useState<number | null>(null);
  const [answers, setAnswers] = useState<number[]>([]);
  const [showResult, setShowResult] = useState(false);
  const [quizCompleted, setQuizCompleted] = useState(false);

  const handleAnswerSelect = (answerIndex: number) => {
    setSelectedAnswer(answerIndex);
  };

  const handleNext = () => {
    if (selectedAnswer === null) return;

    const newAnswers = [...answers, selectedAnswer];
    setAnswers(newAnswers);

    if (currentQuestion < questions.length - 1) {
      setCurrentQuestion(currentQuestion + 1);
      setSelectedAnswer(null);
    } else {
      // Quiz completed
      const correctAnswers = newAnswers.reduce((count, answer, index) => {
        return count + (answer === questions[index].correct ? 1 : 0);
      }, 0);
      
      const score = Math.round((correctAnswers / questions.length) * 100);
      setQuizCompleted(true);
      setShowResult(true);
      onComplete(score);
    }
  };

  const resetQuiz = () => {
    setCurrentQuestion(0);
    setSelectedAnswer(null);
    setAnswers([]);
    setShowResult(false);
    setQuizCompleted(false);
  };

  const correctAnswers = answers.reduce((count, answer, index) => {
    return count + (answer === questions[index].correct ? 1 : 0);
  }, 0);

  const score = quizCompleted ? Math.round((correctAnswers / questions.length) * 100) : 0;

  if (showResult) {
    return (
      <div className="p-8 text-center">
        <div className="mb-8">
          <div className={`text-6xl mb-4 ${score >= 80 ? 'animate-bounce' : ''}`}>
            {score >= 80 ? '🎉' : '📚'}
          </div>
          <h2 className="text-3xl font-bold text-gray-800 dark:text-white mb-4">
            {score >= 80 ? 'Great job! :D' : 'Keep practicing! ^_^'}
          </h2>
          <div className={`text-2xl font-bold mb-4 ${
            score >= 80 ? 'text-green-600' : 'text-yellow-600'
          }`}>
            Score: {score}%
          </div>
          <p className="text-gray-600 dark:text-gray-300 mb-8">
            You got {correctAnswers} out of {questions.length} questions correct!
            {score >= 80 ? ' \\o/' : ' Try again to unlock the next lesson! (•_•)'}
          </p>
        </div>

        {/* Review answers */}
        <div className="bg-gray-50 dark:bg-gray-900 rounded-lg p-6 mb-8 text-left">
          <h3 className="text-xl font-bold text-gray-800 dark:text-white mb-4">Review:</h3>
          {questions.map((question, index) => (
            <div key={index} className="mb-4 p-4 bg-white dark:bg-gray-800 rounded-lg">
              <p className="font-medium text-gray-800 dark:text-white mb-2">
                {index + 1}. {question.question}
              </p>
              <div className="space-y-1">
                {question.options.map((option, optionIndex) => (
                  <div
                    key={optionIndex}
                    className={`p-2 rounded text-sm ${
                      optionIndex === question.correct
                        ? 'bg-green-100 dark:bg-green-900 text-green-800 dark:text-green-200'
                        : answers[index] === optionIndex
                        ? 'bg-red-100 dark:bg-red-900 text-red-800 dark:text-red-200'
                        : 'text-gray-600 dark:text-gray-400'
                    }`}
                  >
                    {optionIndex === question.correct && '✓ '}
                    {answers[index] === optionIndex && optionIndex !== question.correct && '✗ '}
                    {option}
                  </div>
                ))}
              </div>
            </div>
          ))}
        </div>

        <button
          onClick={resetQuiz}
          className="px-6 py-3 bg-gradient-to-r from-blue-500 to-green-500 text-white rounded-lg font-semibold hover:shadow-lg transition-all duration-300"
        >
          Try Again 🔄
        </button>
      </div>
    );
  }

  return (
    <div className="p-8">
      <div className="mb-8">
        <div className="flex items-center justify-between mb-4">
          <h2 className="text-2xl font-bold text-gray-800 dark:text-white">
            Quiz Time! :D
          </h2>
          <div className="text-sm text-gray-600 dark:text-gray-400">
            Question {currentQuestion + 1} of {questions.length}
          </div>
        </div>
        
        {/* Progress bar */}
        <div className="w-full bg-gray-200 dark:bg-gray-700 rounded-full h-2 mb-6">
          <div
            className="bg-gradient-to-r from-blue-500 to-green-500 h-2 rounded-full transition-all duration-300"
            style={{ width: `${((currentQuestion + 1) / questions.length) * 100}%` }}
          />
        </div>
      </div>

      <div className="bg-gray-50 dark:bg-gray-900 rounded-lg p-6 mb-8">
        <h3 className="text-xl font-medium text-gray-800 dark:text-white mb-6">
          {questions[currentQuestion].question}
        </h3>

        <div className="space-y-3">
          {questions[currentQuestion].options.map((option, index) => (
            <button
              key={index}
              onClick={() => handleAnswerSelect(index)}
              className={`w-full p-4 text-left rounded-lg border-2 transition-all duration-200 ${
                selectedAnswer === index
                  ? 'border-blue-500 bg-blue-50 dark:bg-blue-900/20 text-blue-700 dark:text-blue-300'
                  : 'border-gray-200 dark:border-gray-700 bg-white dark:bg-gray-800 text-gray-700 dark:text-gray-300 hover:border-gray-300 dark:hover:border-gray-600'
              }`}
            >
              <div className="flex items-center">
                <div className={`w-4 h-4 rounded-full border-2 mr-3 ${
                  selectedAnswer === index
                    ? 'border-blue-500 bg-blue-500'
                    : 'border-gray-300 dark:border-gray-600'
                }`}>
                  {selectedAnswer === index && (
                    <div className="w-2 h-2 bg-white rounded-full mx-auto mt-0.5" />
                  )}
                </div>
                {option}
              </div>
            </button>
          ))}
        </div>
      </div>

      <div className="flex justify-between items-center">
        <div className="text-sm text-gray-600 dark:text-gray-400">
          {selectedAnswer !== null ? 'Answer selected! ^_^' : 'Choose an answer (•_•)'}
        </div>
        <button
          onClick={handleNext}
          disabled={selectedAnswer === null}
          className="px-6 py-3 bg-gradient-to-r from-blue-500 to-green-500 text-white rounded-lg font-semibold hover:shadow-lg transition-all duration-300 disabled:opacity-50 disabled:cursor-not-allowed"
        >
          {currentQuestion < questions.length - 1 ? 'Next Question →' : 'Finish Quiz! 🎯'}
        </button>
      </div>

      {/* Show current score if quiz was completed before */}
      {currentScore !== null && (
        <div className="mt-6 text-center">
          <div className="inline-block px-4 py-2 bg-gray-100 dark:bg-gray-800 rounded-lg text-sm text-gray-600 dark:text-gray-400">
            Previous best: {currentScore}%
          </div>
        </div>
      )}
    </div>
  );
}
