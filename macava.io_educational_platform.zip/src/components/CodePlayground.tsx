import { useState } from "react";

interface CodePlaygroundProps {
  language: string;
  starterCode: string;
}

export function CodePlayground({ language, starterCode }: CodePlaygroundProps) {
  const [code, setCode] = useState(starterCode);
  const [output, setOutput] = useState("");
  const [isRunning, setIsRunning] = useState(false);

  const runCode = async () => {
    setIsRunning(true);
    setOutput("Running... ⚡");

    // Simulate code execution with delay
    setTimeout(() => {
      try {
        let result = "";
        
        if (language === "python") {
          result = simulatePython(code);
        } else if (language === "javascript") {
          result = simulateJavaScript(code);
        } else if (language === "html") {
          result = "HTML preview updated! Check the preview panel 🎨";
        } else {
          result = `${language.toUpperCase()} code looks good! ✅\n\nNote: This is a preview environment.\nFor full compilation, use a local IDE.`;
        }
        
        setOutput(result);
      } catch (error) {
        setOutput(`Error: ${error} >_<\n\nDon't worry, debugging is part of learning! 💪`);
      }
      setIsRunning(false);
    }, 1000);
  };

  const resetCode = () => {
    setCode(starterCode);
    setOutput("");
  };

  return (
    <div className="p-6">
      <div className="flex items-center justify-between mb-4">
        <h3 className="text-xl font-bold text-gray-800 dark:text-white">
          Code Playground 🎮
        </h3>
        <div className="flex gap-2">
          <button
            onClick={resetCode}
            className="px-4 py-2 bg-gray-200 dark:bg-gray-700 text-gray-700 dark:text-gray-300 rounded-lg hover:bg-gray-300 dark:hover:bg-gray-600 transition-colors text-sm"
          >
            Reset
          </button>
          <button
            onClick={runCode}
            disabled={isRunning}
            className="px-6 py-2 bg-gradient-to-r from-green-500 to-blue-500 text-white rounded-lg font-semibold hover:shadow-lg transition-all duration-300 disabled:opacity-50 disabled:cursor-not-allowed"
          >
            {isRunning ? "Running..." : "Run Code ▶️"}
          </button>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Code Editor */}
        <div>
          <div className="bg-gray-100 dark:bg-gray-900 rounded-lg p-1 mb-2">
            <div className="bg-gray-800 text-gray-300 px-3 py-2 rounded-t text-sm font-mono">
              {language}.{getFileExtension(language)} - Editor
            </div>
          </div>
          <textarea
            value={code}
            onChange={(e) => setCode(e.target.value)}
            className="w-full h-80 p-4 bg-gray-900 text-green-400 font-mono text-sm rounded-b-lg border-0 resize-none focus:ring-2 focus:ring-blue-500 focus:outline-none"
            placeholder="Write your code here... ^_^"
            spellCheck={false}
          />
        </div>

        {/* Output/Preview */}
        <div>
          <div className="bg-gray-100 dark:bg-gray-900 rounded-lg p-1 mb-2">
            <div className="bg-gray-800 text-gray-300 px-3 py-2 rounded-t text-sm font-mono">
              {language === "html" ? "Preview" : "Output"} 📺
            </div>
          </div>
          {language === "html" ? (
            <div className="w-full h-80 bg-white rounded-b-lg border overflow-auto">
              <iframe
                srcDoc={code}
                className="w-full h-full border-0"
                title="HTML Preview"
              />
            </div>
          ) : (
            <div className="w-full h-80 p-4 bg-gray-900 text-gray-300 font-mono text-sm rounded-b-lg overflow-auto whitespace-pre-wrap">
              {output || "Click 'Run Code' to see output here! (•_•)"}
            </div>
          )}
        </div>
      </div>

      {/* Tips */}
      <div className="mt-6 p-4 bg-blue-50 dark:bg-blue-900/20 rounded-lg">
        <h4 className="font-semibold text-blue-800 dark:text-blue-300 mb-2">
          💡 Tips for {language}:
        </h4>
        <div className="text-sm text-blue-700 dark:text-blue-300">
          {getLanguageTips(language)}
        </div>
      </div>
    </div>
  );
}

function simulatePython(code: string): string {
  const lines = code.split('\n');
  let output = "";
  let variables: Record<string, any> = {};

  for (const line of lines) {
    const trimmed = line.trim();
    
    // Skip comments and empty lines
    if (trimmed.startsWith('#') || !trimmed) continue;
    
    // Handle print statements
    if (trimmed.startsWith('print(')) {
      const match = trimmed.match(/print\((.*)\)/);
      if (match) {
        let content = match[1];
        
        // Handle f-strings
        if (content.startsWith('f"') || content.startsWith("f'")) {
          content = content.slice(2, -1);
          content = content.replace(/\{(\w+)\}/g, (_, varName) => {
            return variables[varName] || `{${varName}}`;
          });
        }
        // Handle regular strings
        else if (content.startsWith('"') || content.startsWith("'")) {
          content = content.slice(1, -1);
        }
        // Handle variables and expressions
        else {
          const parts = content.split(',').map(part => {
            const trimmedPart = part.trim();
            if (trimmedPart.startsWith('"') || trimmedPart.startsWith("'")) {
              return trimmedPart.slice(1, -1);
            }
            return variables[trimmedPart] || trimmedPart;
          });
          content = parts.join(' ');
        }
        
        output += content + '\n';
      }
    }
    
    // Handle variable assignments
    else if (trimmed.includes('=') && !trimmed.includes('==')) {
      const [varName, value] = trimmed.split('=').map(s => s.trim());
      if (value.startsWith('"') || value.startsWith("'")) {
        variables[varName] = value.slice(1, -1);
      } else if (!isNaN(Number(value))) {
        variables[varName] = Number(value);
      } else {
        variables[varName] = value;
      }
    }
  }

  return output || "Code executed successfully! ^_^\n(No output to display)";
}

function simulateJavaScript(code: string): string {
  let output = "";
  
  // Override console.log to capture output
  const originalLog = console.log;
  const logs: string[] = [];
  
  console.log = (...args) => {
    logs.push(args.map(arg => String(arg)).join(' '));
  };
  
  try {
    // Execute the code
    eval(code);
    output = logs.join('\n');
  } catch (error) {
    output = `Error: ${error}`;
  } finally {
    // Restore original console.log
    console.log = originalLog;
  }
  
  return output || "Code executed successfully! ⚡\n(No output to display)";
}

function getFileExtension(language: string): string {
  const extensions: Record<string, string> = {
    python: "py",
    javascript: "js",
    html: "html",
    c: "c",
    cpp: "cpp"
  };
  return extensions[language] || "txt";
}

function getLanguageTips(language: string): string {
  const tips: Record<string, string> = {
    python: "• Use print() to see output • Variables don't need declaration • Indentation matters! • Try f-strings: f'Hello {name}'",
    javascript: "• Use console.log() for output • Declare with let/const • Template literals: `Hello ${name}` • Semicolons are optional but good practice",
    html: "• Every tag should close • Use proper nesting • Add alt text to images • Preview updates automatically!",
    c: "• Include headers with #include • Every program needs main() • Don't forget semicolons • Compile before running",
    cpp: "• Similar to C but with classes • Use std:: or 'using namespace std' • cout for output • Object-oriented features available"
  };
  return tips[language] || "• Experiment and have fun! • Read error messages carefully • Practice makes perfect ^_^";
}
