import { useQuery } from "convex/react";
import { api } from "../../convex/_generated/api";

export function AIProviderInfo() {
  const currentProvider = useQuery(api.chat.getCurrentProvider);
  
  const providerNames: Record<string, string> = {
    openai: "OpenAI (gpt-4o-mini)",
    gemini: "Google Gemini",
    grok: "xAI Grok"
  };
  
  const providerName = currentProvider ? providerNames[currentProvider] || currentProvider : "Loading...";
  
  return (
    <div className="fixed bottom-24 left-6 bg-white dark:bg-gray-800 rounded-lg shadow-lg p-3 text-xs max-w-xs z-40">
      <div className="flex items-center gap-2 mb-2">
        <div className="w-2 h-2 bg-green-500 rounded-full animate-pulse"></div>
        <span className="font-semibold text-gray-800 dark:text-white">Maca AI Status</span>
      </div>
      <div className="text-gray-600 dark:text-gray-300 space-y-1">
        <p>
          <span className="font-mono">^_^</span> Currently using: <strong>{providerName}</strong>
        </p>
        <p className="text-[10px] opacity-75">
          {currentProvider === "openai" 
            ? "Using bundled keys. Switch to Gemini/Grok by adding API keys."
            : "Custom AI provider configured!"}
        </p>
      </div>
      <details className="mt-2">
        <summary className="cursor-pointer text-blue-600 dark:text-blue-400 hover:underline">
          Setup Guide
        </summary>
        <div className="mt-2 text-[10px] space-y-1 text-gray-600 dark:text-gray-400">
          <p><strong>Gemini:</strong> Get key from ai.google.dev</p>
          <p><strong>Grok:</strong> Get key from console.x.ai</p>
          <p className="mt-1">
            Add <code className="bg-gray-100 dark:bg-gray-700 px-1 rounded">AI_PROVIDER</code> and 
            <code className="bg-gray-100 dark:bg-gray-700 px-1 rounded ml-1">GEMINI_API_KEY</code> or 
            <code className="bg-gray-100 dark:bg-gray-700 px-1 rounded ml-1">GROK_API_KEY</code> in 
            Convex Dashboard → Settings → Environment Variables
          </p>
        </div>
      </details>
    </div>
  );
}
