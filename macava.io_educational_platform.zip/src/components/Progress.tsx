import { useQuery } from "convex/react";
import { api } from "../../convex/_generated/api";

export function Progress() {
  const userProgress = useQuery(api.progress.getUserProgress);

  if (!userProgress) {
    return (
      <div className="flex justify-center items-center min-h-[50vh]">
        <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-blue-500"></div>
      </div>
    );
  }

  const { progress, streak } = userProgress;
  const completedLessons = progress.filter(p => p.completed).length;
  const totalScore = progress.reduce((sum, p) => sum + (p.score || 0), 0);
  const averageScore = progress.length > 0 ? Math.round(totalScore / progress.length) : 0;

  const languageStats = progress.reduce((acc, p) => {
    if (!acc[p.language]) {
      acc[p.language] = { completed: 0, total: 0, totalScore: 0 };
    }
    acc[p.language].total++;
    if (p.completed) acc[p.language].completed++;
    acc[p.language].totalScore += p.score || 0;
    return acc;
  }, {} as Record<string, { completed: number; total: number; totalScore: number }>);

  return (
    <div className="max-w-6xl mx-auto">
      <div className="text-center mb-12">
        <h1 className="text-4xl md:text-5xl font-bold text-gray-800 dark:text-white mb-4">
          Your Progress \\o/
        </h1>
        <p className="text-xl text-gray-600 dark:text-gray-300">
          Look how far you've come! Keep it up ^_^
        </p>
      </div>

      {/* Overall Stats */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-6 mb-12">
        <StatCard
          title="Lessons Completed"
          value={completedLessons}
          emoji="📚"
          color="from-blue-400 to-blue-600"
        />
        <StatCard
          title="Current Streak"
          value={streak.currentStreak}
          emoji="🔥"
          color="from-orange-400 to-red-600"
        />
        <StatCard
          title="Longest Streak"
          value={streak.longestStreak}
          emoji="🏆"
          color="from-yellow-400 to-orange-600"
        />
        <StatCard
          title="Average Score"
          value={`${averageScore}%`}
          emoji="⭐"
          color="from-green-400 to-green-600"
        />
      </div>

      {/* Language Progress */}
      <div className="bg-white dark:bg-gray-800 rounded-2xl shadow-xl p-8 mb-8">
        <h2 className="text-2xl font-bold text-gray-800 dark:text-white mb-6">
          Language Progress 📊
        </h2>
        <div className="space-y-6">
          {Object.entries(languageStats).map(([language, stats]) => (
            <LanguageProgressBar
              key={language}
              language={language}
              completed={stats.completed}
              total={stats.total}
              averageScore={Math.round(stats.totalScore / stats.total)}
            />
          ))}
        </div>
      </div>

      {/* Recent Activity */}
      <div className="bg-white dark:bg-gray-800 rounded-2xl shadow-xl p-8">
        <h2 className="text-2xl font-bold text-gray-800 dark:text-white mb-6">
          Recent Activity 📝
        </h2>
        <div className="space-y-4">
          {progress
            .filter(p => p.completedAt)
            .sort((a, b) => (b.completedAt || 0) - (a.completedAt || 0))
            .slice(0, 10)
            .map((p, index) => (
              <ActivityItem
                key={`${p.language}-${p.lessonId}-${index}`}
                language={p.language}
                lessonId={p.lessonId}
                score={p.score || 0}
                completedAt={p.completedAt || 0}
                completed={p.completed}
              />
            ))}
        </div>
      </div>

      {/* Motivational Message */}
      <div className="text-center mt-12">
        <div className="inline-block bg-gradient-to-r from-blue-100 to-green-100 dark:from-blue-900 dark:to-green-900 rounded-xl p-6">
          <p className="text-lg text-gray-700 dark:text-gray-300">
            {completedLessons === 0 ? (
              <>
                <span className="font-mono">(•_•)</span> Ready to start your first lesson? You've got this!
              </>
            ) : completedLessons < 5 ? (
              <>
                <span className="font-mono">^_^</span> Great start! Keep the momentum going!
              </>
            ) : (
              <>
                <span className="font-mono">\\o/</span> You're doing amazing! Keep up the excellent work!
              </>
            )}
          </p>
        </div>
      </div>
    </div>
  );
}

function StatCard({ 
  title, 
  value, 
  emoji, 
  color 
}: { 
  title: string; 
  value: string | number; 
  emoji: string; 
  color: string; 
}) {
  return (
    <div className={`bg-gradient-to-r ${color} rounded-xl shadow-lg p-6 text-white text-center`}>
      <div className="text-3xl mb-2">{emoji}</div>
      <div className="text-3xl font-bold mb-1">{value}</div>
      <div className="text-sm opacity-90">{title}</div>
    </div>
  );
}

function LanguageProgressBar({ 
  language, 
  completed, 
  total, 
  averageScore 
}: { 
  language: string; 
  completed: number; 
  total: number; 
  averageScore: number; 
}) {
  const percentage = (completed / total) * 100;
  
  const languageEmojis: Record<string, string> = {
    python: "/\\",
    c: "[O]",
    cpp: "O->",
    javascript: "/|",
    "html-css": "[]"
  };

  return (
    <div className="space-y-2">
      <div className="flex justify-between items-center">
        <div className="flex items-center space-x-2">
          <span className="font-mono text-blue-600 dark:text-blue-400">
            {languageEmojis[language] || "•"}
          </span>
          <span className="font-semibold text-gray-800 dark:text-white capitalize">
            {language.replace("-", " & ")}
          </span>
        </div>
        <div className="text-sm text-gray-600 dark:text-gray-400">
          {completed}/{total} lessons • {averageScore}% avg
        </div>
      </div>
      <div className="w-full bg-gray-200 dark:bg-gray-700 rounded-full h-3">
        <div
          className="bg-gradient-to-r from-blue-500 to-green-500 h-3 rounded-full transition-all duration-500"
          style={{ width: `${percentage}%` }}
        />
      </div>
    </div>
  );
}

function ActivityItem({ 
  language, 
  lessonId, 
  score, 
  completedAt, 
  completed 
}: { 
  language: string; 
  lessonId: string; 
  score: number; 
  completedAt: number; 
  completed: boolean; 
}) {
  const date = new Date(completedAt).toLocaleDateString();
  const time = new Date(completedAt).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });

  return (
    <div className="flex items-center justify-between p-4 bg-gray-50 dark:bg-gray-700 rounded-lg">
      <div className="flex items-center space-x-3">
        <div className={`w-3 h-3 rounded-full ${completed ? 'bg-green-500' : 'bg-yellow-500'}`} />
        <div>
          <div className="font-medium text-gray-800 dark:text-white">
            {language.charAt(0).toUpperCase() + language.slice(1)} - {lessonId}
          </div>
          <div className="text-sm text-gray-600 dark:text-gray-400">
            {date} at {time}
          </div>
        </div>
      </div>
      <div className="text-right">
        <div className={`font-semibold ${score >= 80 ? 'text-green-600' : 'text-yellow-600'}`}>
          {score}%
        </div>
        <div className="text-xs text-gray-500">
          {completed ? "Completed ^_^" : "In Progress"}
        </div>
      </div>
    </div>
  );
}
