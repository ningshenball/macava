import { useQuery } from "convex/react";
import { api } from "../../convex/_generated/api";
import { useEffect, useState } from "react";

interface HomeProps {
  startLesson: (language: string, lessonId: string) => void;
}

export function Home({ startLesson }: HomeProps) {
  const userProgress = useQuery(api.progress.getUserProgress);
  const [confetti, setConfetti] = useState<Array<{id: number, x: number, char: string}>>([]);

  useEffect(() => {
    // Animated ASCII confetti
    const symbols = ["*", "^", "~", "•", "◦", "∘"];
    const newConfetti = Array.from({ length: 15 }, (_, i) => ({
      id: i,
      x: Math.random() * 100,
      char: symbols[Math.floor(Math.random() * symbols.length)]
    }));
    setConfetti(newConfetti);
  }, []);

  const completedLessons = userProgress?.progress?.filter(p => p.completed).length || 0;
  const currentStreak = userProgress?.streak?.currentStreak || 0;

  return (
    <div className="max-w-6xl mx-auto">
      {/* Hero Section */}
      <div className="text-center mb-12 relative overflow-hidden">
        {/* Animated confetti */}
        <div className="absolute inset-0 pointer-events-none">
          {confetti.map((item) => (
            <div
              key={item.id}
              className="absolute text-blue-400 dark:text-blue-300 animate-bounce opacity-60"
              style={{
                left: `${item.x}%`,
                animationDelay: `${Math.random() * 2}s`,
                animationDuration: `${2 + Math.random() * 2}s`
              }}
            >
              {item.char}
            </div>
          ))}
        </div>

        <h1 className="text-5xl md:text-7xl font-bold mb-6 bg-gradient-to-r from-blue-600 to-green-600 bg-clip-text text-transparent animate-fade-in">
          Start Your Coding Adventure on Macava.io! ^_^
        </h1>
        <p className="text-xl md:text-2xl text-gray-600 dark:text-gray-300 mb-8 animate-fade-in-delay">
          Your friendly study buddy for Python, C, C++, JavaScript, HTML & CSS
        </p>

        {/* ASCII Border */}
        <div className="text-center text-gray-400 dark:text-gray-600 font-mono text-sm mb-8">
          ─────────────────────────────────────────────────────────
        </div>
      </div>

      {/* Progress Overview */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-12">
        <StatsCard
          title="Lessons Completed"
          value={completedLessons}
          emoji="📚"
          subtitle="Keep learning! :D"
        />
        <StatsCard
          title="Current Streak"
          value={currentStreak}
          emoji="🔥"
          subtitle={currentStreak > 0 ? "You're on fire! \\o/" : "Start today! (•_•)"}
        />
        <StatsCard
          title="Languages"
          value="5"
          emoji="💻"
          subtitle="Ready to explore! ^_^"
        />
      </div>

      {/* Quick Start */}
      <div className="bg-white dark:bg-gray-800 rounded-2xl shadow-xl p-8 mb-8">
        <h2 className="text-3xl font-bold text-gray-800 dark:text-white mb-6 text-center">
          Quick Start Your Journey! 🚀
        </h2>
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
          <QuickStartCard
            title="Python Basics"
            emoji="/\\"
            description="Variables and print statements"
            onClick={() => startLesson("python", "basics")}
          />
          <QuickStartCard
            title="JavaScript Intro"
            emoji="/|"
            description="Console.log and variables"
            onClick={() => startLesson("javascript", "intro")}
          />
          <QuickStartCard
            title="HTML Structure"
            emoji="[]"
            description="Tags and elements"
            onClick={() => startLesson("html", "structure")}
          />
        </div>
      </div>

      {/* Daily Reminder */}
      <div className="text-center">
        <div className="inline-block bg-gradient-to-r from-blue-100 to-green-100 dark:from-blue-900 dark:to-green-900 rounded-xl p-6">
          <p className="text-lg text-gray-700 dark:text-gray-300">
            <span className="font-mono">(•_•)</span> Ready to code today? Let's make progress together!
          </p>
        </div>
      </div>
    </div>
  );
}

function StatsCard({ 
  title, 
  value, 
  emoji, 
  subtitle 
}: { 
  title: string; 
  value: string | number; 
  emoji: string; 
  subtitle: string; 
}) {
  return (
    <div className="bg-white dark:bg-gray-800 rounded-xl shadow-lg p-6 text-center hover:shadow-xl transition-shadow duration-300">
      <div className="text-3xl mb-2">{emoji}</div>
      <div className="text-3xl font-bold text-gray-800 dark:text-white mb-1">{value}</div>
      <div className="text-gray-600 dark:text-gray-400 font-medium mb-2">{title}</div>
      <div className="text-sm text-gray-500 dark:text-gray-500">{subtitle}</div>
    </div>
  );
}

function QuickStartCard({ 
  title, 
  emoji, 
  description, 
  onClick 
}: { 
  title: string; 
  emoji: string; 
  description: string; 
  onClick: () => void; 
}) {
  return (
    <button
      onClick={onClick}
      className="bg-gradient-to-br from-blue-50 to-green-50 dark:from-blue-900/20 dark:to-green-900/20 rounded-xl p-4 text-left hover:shadow-lg transition-all duration-300 hover:scale-105 border border-gray-200 dark:border-gray-700"
    >
      <div className="font-mono text-lg text-blue-600 dark:text-blue-400 mb-2">{emoji}</div>
      <div className="font-semibold text-gray-800 dark:text-white mb-1">{title}</div>
      <div className="text-sm text-gray-600 dark:text-gray-400">{description}</div>
    </button>
  );
}
