import { useState } from "react";
import { MultiLanguagePlayground } from "./MultiLanguagePlayground";

interface Concept {
  id: string;
  title: string;
  description: string;
  code: string;
  explanation: string;
}

interface BasicConceptsProps {
  language: string;
}

const concepts: Record<string, Concept[]> = {
  python: [
    {
      id: "variables",
      title: "Variables & Data Types",
      description: "Store and work with different types of data",
      code: `# Variables are like labeled boxes 📦
name = "Coder"           # String (text)
age = 20                 # Integer (whole number)
height = 5.8             # Float (decimal)
is_learning = True       # Boolean (True/False)

# Print them out
print("Name:", name)
print("Age:", age)
print("Height:", height)
print("Learning?", is_learning)

# F-strings for formatting
print(f"Hi! I'm {name}, {age} years old!")`,
      explanation: "Variables store data. Python automatically figures out the type!"
    },
    {
      id: "lists",
      title: "Lists & Loops",
      description: "Store multiple items and iterate through them",
      code: `# Lists hold multiple items 📝
fruits = ["apple", "banana", "orange"]
numbers = [1, 2, 3, 4, 5]

# Access items by index (starts at 0)
print("First fruit:", fruits[0])
print("Last number:", numbers[-1])

# Loop through lists
print("\\nAll fruits:")
for fruit in fruits:
    print(f"- {fruit}")

# List operations
fruits.append("grape")
print(f"\\nNow we have {len(fruits)} fruits!")`,
      explanation: "Lists are ordered collections. Use loops to process each item!"
    },
    {
      id: "functions",
      title: "Functions",
      description: "Reusable blocks of code that perform specific tasks",
      code: `# Functions are like mini-programs 🔧
def greet(name):
    return f"Hello, {name}! ^_^"

def add_numbers(a, b):
    result = a + b
    return result

def calculate_area(length, width):
    area = length * width
    print(f"Rectangle area: {area}")
    return area

# Use the functions
message = greet("Macava Student")
print(message)

sum_result = add_numbers(10, 5)
print(f"10 + 5 = {sum_result}")

room_area = calculate_area(12, 8)`,
      explanation: "Functions help organize code and avoid repetition. Define once, use many times!"
    }
  ],
  javascript: [
    {
      id: "variables",
      title: "Variables & Data Types",
      description: "Store and manipulate different types of data",
      code: `// Variables in JavaScript ⚡
let name = "Coder";              // String (changeable)
const age = 20;                  // Number (unchangeable)
let isLearning = true;           // Boolean
let hobbies = ["coding", "gaming"]; // Array

// Display values
console.log("Name:", name);
console.log("Age:", age);
console.log("Learning?", isLearning);
console.log("Hobbies:", hobbies);

// Template literals with backticks
console.log(\`Hi! I'm \${name}, \${age} years old!\`);

// Change variables (only let, not const)
name = "JavaScript Master";
console.log("New name:", name);`,
      explanation: "Use 'let' for changeable variables, 'const' for constants!"
    },
    {
      id: "arrays",
      title: "Arrays & Loops",
      description: "Work with collections of data",
      code: `// Arrays store multiple values 📚
const colors = ["red", "green", "blue"];
const numbers = [1, 2, 3, 4, 5];

// Access elements (starts at 0)
console.log("First color:", colors[0]);
console.log("Last number:", numbers[numbers.length - 1]);

// Loop through arrays
console.log("\\nAll colors:");
for (let i = 0; i < colors.length; i++) {
    console.log(\`\${i + 1}. \${colors[i]}\`);
}

// Modern way with forEach
console.log("\\nNumbers doubled:");
numbers.forEach(num => {
    console.log(\`\${num} × 2 = \${num * 2}\`);
});

// Array methods
colors.push("yellow");
console.log("Added yellow:", colors);`,
      explanation: "Arrays are ordered lists. Use loops to process each element!"
    },
    {
      id: "functions",
      title: "Functions",
      description: "Reusable code blocks for specific tasks",
      code: `// Functions in JavaScript 🚀
function greet(name) {
    return \`Hello, \${name}! Welcome to JS! ⚡\`;
}

// Arrow function (modern syntax)
const addNumbers = (a, b) => {
    return a + b;
};

// Short arrow function
const multiply = (x, y) => x * y;

// Function with default parameter
function introduce(name = "Anonymous") {
    console.log(\`Hi, I'm \${name}!\`);
}

// Use the functions
console.log(greet("JavaScript Learner"));
console.log("5 + 3 =", addNumbers(5, 3));
console.log("4 × 7 =", multiply(4, 7));

introduce("Alex");
introduce(); // Uses default value`,
      explanation: "Functions make code reusable. Arrow functions are a modern, concise syntax!"
    }
  ],
  html: [
    {
      id: "structure",
      title: "HTML Structure",
      description: "Basic HTML document structure and common tags",
      code: `<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>My First Webpage! ^_^</title>
</head>
<body>
    <h1>Welcome to HTML!</h1>
    <h2>About This Page</h2>
    <p>This is a <strong>paragraph</strong> with <em>emphasis</em>.</p>
    
    <h3>My Favorite Things:</h3>
    <ul>
        <li>Learning HTML</li>
        <li>Building websites</li>
        <li>Coding with Macava.io</li>
    </ul>
    
    <p>Visit <a href="https://macava.io" target="_blank">Macava.io</a> for more lessons!</p>
</body>
</html>`,
      explanation: "HTML uses tags to structure content. Every tag should have a closing tag!"
    },
    {
      id: "forms",
      title: "Forms & Input",
      description: "Create interactive forms to collect user input",
      code: `<!DOCTYPE html>
<html>
<head>
    <title>Contact Form</title>
    <style>
        body { font-family: Arial, sans-serif; margin: 20px; }
        form { max-width: 400px; }
        label { display: block; margin-top: 10px; }
        input, textarea { width: 100%; padding: 8px; margin-top: 5px; }
        button { background: #007bff; color: white; padding: 10px 20px; border: none; margin-top: 10px; }
    </style>
</head>
<body>
    <h1>Contact Us! 📧</h1>
    <form>
        <label for="name">Name:</label>
        <input type="text" id="name" name="name" required>
        
        <label for="email">Email:</label>
        <input type="email" id="email" name="email" required>
        
        <label for="message">Message:</label>
        <textarea id="message" name="message" rows="4" required></textarea>
        
        <button type="submit">Send Message</button>
    </form>
</body>
</html>`,
      explanation: "Forms collect user input. Use different input types for different data!"
    },
    {
      id: "styling",
      title: "CSS Styling",
      description: "Add colors, fonts, and layout to your HTML",
      code: `<!DOCTYPE html>
<html>
<head>
    <title>Styled Page</title>
    <style>
        body {
            font-family: 'Arial', sans-serif;
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            color: white;
            margin: 0;
            padding: 20px;
        }
        
        .container {
            max-width: 600px;
            margin: 0 auto;
            background: rgba(255, 255, 255, 0.1);
            padding: 30px;
            border-radius: 15px;
            backdrop-filter: blur(10px);
        }
        
        h1 {
            text-align: center;
            font-size: 2.5em;
            margin-bottom: 20px;
            text-shadow: 2px 2px 4px rgba(0,0,0,0.3);
        }
        
        .card {
            background: rgba(255, 255, 255, 0.2);
            padding: 20px;
            margin: 15px 0;
            border-radius: 10px;
            border-left: 4px solid #ffd700;
        }
        
        .highlight {
            color: #ffd700;
            font-weight: bold;
        }
    </style>
</head>
<body>
    <div class="container">
        <h1>🎨 Styled with CSS!</h1>
        <div class="card">
            <h3>Welcome to <span class="highlight">Macava.io</span>!</h3>
            <p>This page uses CSS to look amazing! ✨</p>
        </div>
        <div class="card">
            <h3>CSS Features Used:</h3>
            <ul>
                <li>Gradient backgrounds</li>
                <li>Glass morphism effects</li>
                <li>Custom fonts and colors</li>
                <li>Responsive design</li>
            </ul>
        </div>
    </div>
</body>
</html>`,
      explanation: "CSS makes HTML beautiful! Use classes and IDs to style specific elements."
    }
  ],
  c: [
    {
      id: "hello",
      title: "Hello World & Variables",
      description: "Your first C program with variables",
      code: `#include <stdio.h>

int main() {
    // Variables in C 🔧
    int age = 20;
    float height = 5.8;
    char grade = 'A';
    char name[] = "Coder";
    
    // Print output
    printf("Hello, Macava! ^_^\\n");
    printf("Name: %s\\n", name);
    printf("Age: %d years\\n", age);
    printf("Height: %.1f feet\\n", height);
    printf("Grade: %c\\n", grade);
    
    // Simple calculation
    int birth_year = 2024 - age;
    printf("Born in: %d\\n", birth_year);
    
    return 0;
}`,
      explanation: "C requires #include for libraries, main() function, and specific format specifiers for printf!"
    },
    {
      id: "loops",
      title: "Loops & Arrays",
      description: "Iterate through data with loops",
      code: `#include <stdio.h>

int main() {
    // Arrays in C 📊
    int numbers[] = {1, 2, 3, 4, 5};
    int size = 5;
    
    printf("Numbers array:\\n");
    
    // For loop
    for (int i = 0; i < size; i++) {
        printf("numbers[%d] = %d\\n", i, numbers[i]);
    }
    
    // Calculate sum
    int sum = 0;
    for (int i = 0; i < size; i++) {
        sum += numbers[i];
    }
    
    printf("\\nSum: %d\\n", sum);
    printf("Average: %.2f\\n", (float)sum / size);
    
    // While loop countdown
    printf("\\nCountdown: ");
    int count = 5;
    while (count > 0) {
        printf("%d ", count);
        count--;
    }
    printf("Go! 🚀\\n");
    
    return 0;
}`,
      explanation: "C arrays have fixed size. Use loops to process elements efficiently!"
    },
    {
      id: "functions",
      title: "Functions",
      description: "Create reusable code with functions",
      code: `#include <stdio.h>

// Function declarations
int add(int a, int b);
float calculate_area(float length, float width);
void print_greeting(char name[]);

int main() {
    // Use functions 🔧
    printf("=== C Functions Demo ===\\n");
    
    // Math function
    int result = add(15, 25);
    printf("15 + 25 = %d\\n", result);
    
    // Area calculation
    float area = calculate_area(10.5, 8.2);
    printf("Area: %.2f square units\\n", area);
    
    // Greeting function
    print_greeting("Macava Student");
    
    return 0;
}

// Function definitions
int add(int a, int b) {
    return a + b;
}

float calculate_area(float length, float width) {
    return length * width;
}

void print_greeting(char name[]) {
    printf("Hello, %s! Welcome to C programming! ^_^\\n", name);
}`,
      explanation: "C functions must be declared before use. Specify return type and parameter types!"
    }
  ],
  cpp: [
    {
      id: "hello",
      title: "Hello World & Variables",
      description: "Modern C++ with iostream and variables",
      code: `#include <iostream>
#include <string>
using namespace std;

int main() {
    // Variables in C++ 🚀
    int age = 20;
    double height = 5.8;
    char grade = 'A';
    string name = "Coder";
    bool isLearning = true;
    
    // Output with cout
    cout << "Hello, Macava! ^_^" << endl;
    cout << "Name: " << name << endl;
    cout << "Age: " << age << " years" << endl;
    cout << "Height: " << height << " feet" << endl;
    cout << "Grade: " << grade << endl;
    cout << "Learning? " << (isLearning ? "Yes" : "No") << endl;
    
    // Simple calculation
    int birthYear = 2024 - age;
    cout << "Born in: " << birthYear << endl;
    
    return 0;
}`,
      explanation: "C++ uses cout for output and supports string type. Much easier than C's printf!"
    },
    {
      id: "vectors",
      title: "Vectors & Loops",
      description: "Dynamic arrays and modern C++ loops",
      code: `#include <iostream>
#include <vector>
#include <string>
using namespace std;

int main() {
    // Vectors (dynamic arrays) 📚
    vector<int> numbers = {1, 2, 3, 4, 5};
    vector<string> languages = {"C++", "Python", "JavaScript"};
    
    cout << "Numbers:" << endl;
    
    // Range-based for loop (C++11)
    for (int num : numbers) {
        cout << num << " ";
    }
    cout << endl;
    
    // Traditional for loop with size()
    cout << "\\nLanguages:" << endl;
    for (size_t i = 0; i < languages.size(); i++) {
        cout << i + 1 << ". " << languages[i] << endl;
    }
    
    // Add elements
    numbers.push_back(6);
    languages.push_back("HTML");
    
    cout << "\\nAfter adding elements:" << endl;
    cout << "Numbers size: " << numbers.size() << endl;
    cout << "Last language: " << languages.back() << endl;
    
    return 0;
}`,
      explanation: "Vectors are dynamic arrays that can grow/shrink. Use range-based loops for cleaner code!"
    },
    {
      id: "classes",
      title: "Classes & Objects",
      description: "Object-oriented programming basics",
      code: `#include <iostream>
#include <string>
using namespace std;

// Class definition 🏗️
class Student {
private:
    string name;
    int age;
    double gpa;

public:
    // Constructor
    Student(string n, int a, double g) {
        name = n;
        age = a;
        gpa = g;
    }
    
    // Methods
    void introduce() {
        cout << "Hi! I'm " << name << ", " << age << " years old." << endl;
    }
    
    void showGPA() {
        cout << "My GPA is: " << gpa << endl;
    }
    
    // Getter methods
    string getName() { return name; }
    int getAge() { return age; }
};

int main() {
    // Create objects 🎯
    Student student1("Alice", 20, 3.8);
    Student student2("Bob", 19, 3.6);
    
    cout << "=== Student Information ===" << endl;
    
    student1.introduce();
    student1.showGPA();
    
    cout << endl;
    
    student2.introduce();
    student2.showGPA();
    
    cout << "\\n" << student1.getName() << " is older than " 
         << student2.getName() << "? " 
         << (student1.getAge() > student2.getAge() ? "Yes" : "No") << endl;
    
    return 0;
}`,
      explanation: "Classes bundle data and functions together. Use constructors to initialize objects!"
    }
  ]
};

export function BasicConcepts({ language }: BasicConceptsProps) {
  const [selectedConcept, setSelectedConcept] = useState<string | null>(null);
  const languageConcepts = concepts[language] || [];

  if (languageConcepts.length === 0) {
    return (
      <div className="p-8 text-center">
        <div className="text-6xl mb-4">🚧</div>
        <h2 className="text-2xl font-bold text-gray-800 dark:text-white mb-4">
          Concepts Coming Soon! (•_•)
        </h2>
        <p className="text-gray-600 dark:text-gray-300">
          We're preparing awesome {language} concepts for you! Check back soon ^_^
        </p>
      </div>
    );
  }

  if (selectedConcept) {
    const concept = languageConcepts.find(c => c.id === selectedConcept);
    if (!concept) return null;

    return (
      <div className="max-w-6xl mx-auto">
        <div className="flex items-center justify-between mb-6">
          <div>
            <h2 className="text-2xl font-bold text-gray-800 dark:text-white">
              {concept.title}
            </h2>
            <p className="text-gray-600 dark:text-gray-300">
              {concept.description}
            </p>
          </div>
          <button
            onClick={() => setSelectedConcept(null)}
            className="px-4 py-2 bg-gray-200 dark:bg-gray-700 text-gray-700 dark:text-gray-300 rounded-lg hover:bg-gray-300 dark:hover:bg-gray-600 transition-colors"
          >
            ← Back to Concepts
          </button>
        </div>

        <div className="bg-blue-50 dark:bg-blue-900/20 rounded-lg p-4 mb-6">
          <h3 className="font-semibold text-blue-800 dark:text-blue-300 mb-2">
            💡 What you'll learn:
          </h3>
          <p className="text-blue-700 dark:text-blue-300">
            {concept.explanation}
          </p>
        </div>

        <MultiLanguagePlayground 
          language={language}
          template={concept.code}
        />
      </div>
    );
  }

  return (
    <div className="max-w-4xl mx-auto">
      <div className="text-center mb-8">
        <h2 className="text-3xl font-bold text-gray-800 dark:text-white mb-4">
          {language.charAt(0).toUpperCase() + language.slice(1)} Concepts 📚
        </h2>
        <p className="text-gray-600 dark:text-gray-300">
          Learn fundamental concepts with interactive examples! ^_^
        </p>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {languageConcepts.map((concept) => (
          <div
            key={concept.id}
            onClick={() => setSelectedConcept(concept.id)}
            className="lesson-card cursor-pointer group"
          >
            <h3 className="text-lg font-semibold text-gray-800 dark:text-white mb-2 group-hover:text-blue-600 dark:group-hover:text-blue-400 transition-colors">
              {concept.title}
            </h3>
            <p className="text-gray-600 dark:text-gray-300 text-sm mb-4">
              {concept.description}
            </p>
            <div className="flex items-center justify-between">
              <span className="text-xs text-gray-500 dark:text-gray-400">
                Interactive Example
              </span>
              <span className="text-blue-500 group-hover:translate-x-1 transition-transform">
                →
              </span>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}
