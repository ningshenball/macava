import { SignOutButton } from "../SignOutButton";
import { Authenticated } from "convex/react";

type Page = "home" | "languages" | "progress" | "lesson";

interface NavigationProps {
  currentPage: Page;
  setCurrentPage: (page: Page) => void;
  darkMode: boolean;
  setDarkMode: (dark: boolean) => void;
  goHome: () => void;
}

export function Navigation({ 
  currentPage, 
  setCurrentPage, 
  darkMode, 
  setDarkMode,
  goHome 
}: NavigationProps) {
  return (
    <nav className="fixed top-0 left-0 right-0 z-50 bg-white/90 dark:bg-gray-900/90 backdrop-blur-sm border-b border-gray-200 dark:border-gray-700">
      <div className="container mx-auto px-4">
        <div className="flex items-center justify-between h-16">
          {/* Logo */}
          <button 
            onClick={goHome}
            className="text-2xl font-bold bg-gradient-to-r from-blue-500 to-green-500 bg-clip-text text-transparent hover:scale-105 transition-transform"
          >
            Macava.io
          </button>

          {/* Desktop Navigation */}
          <Authenticated>
            <div className="hidden md:flex items-center space-x-8">
              <NavLink 
                active={currentPage === "home"} 
                onClick={() => setCurrentPage("home")}
              >
                Home
              </NavLink>
              <NavLink 
                active={currentPage === "languages"} 
                onClick={() => setCurrentPage("languages")}
              >
                Languages
              </NavLink>
              <NavLink 
                active={currentPage === "progress"} 
                onClick={() => setCurrentPage("progress")}
              >
                Progress
              </NavLink>
            </div>
          </Authenticated>

          {/* Right side controls */}
          <div className="flex items-center space-x-4">
            {/* Dark mode toggle */}
            <button
              onClick={() => setDarkMode(!darkMode)}
              className="p-2 rounded-lg bg-gray-100 dark:bg-gray-800 hover:bg-gray-200 dark:hover:bg-gray-700 transition-colors"
              aria-label="Toggle dark mode"
            >
              {darkMode ? (
                <span className="text-yellow-500">☀️</span>
              ) : (
                <span className="text-gray-700">🌙</span>
              )}
            </button>
            
            <Authenticated>
              <SignOutButton />
            </Authenticated>
          </div>
        </div>

        {/* Mobile Navigation */}
        <Authenticated>
          <div className="md:hidden pb-4">
            <div className="flex space-x-4">
              <NavLink 
                active={currentPage === "home"} 
                onClick={() => setCurrentPage("home")}
                mobile
              >
                Home
              </NavLink>
              <NavLink 
                active={currentPage === "languages"} 
                onClick={() => setCurrentPage("languages")}
                mobile
              >
                Languages
              </NavLink>
              <NavLink 
                active={currentPage === "progress"} 
                onClick={() => setCurrentPage("progress")}
                mobile
              >
                Progress
              </NavLink>
            </div>
          </div>
        </Authenticated>
      </div>
    </nav>
  );
}

function NavLink({ 
  children, 
  active, 
  onClick, 
  mobile = false 
}: { 
  children: React.ReactNode; 
  active: boolean; 
  onClick: () => void;
  mobile?: boolean;
}) {
  return (
    <button
      onClick={onClick}
      className={`${
        mobile ? "text-sm px-3 py-1" : "px-4 py-2"
      } rounded-lg font-medium transition-all duration-200 ${
        active
          ? "bg-gradient-to-r from-blue-500 to-green-500 text-white shadow-lg"
          : "text-gray-600 dark:text-gray-300 hover:text-blue-500 dark:hover:text-blue-400 hover:bg-gray-100 dark:hover:bg-gray-800"
      }`}
    >
      {children}
    </button>
  );
}
