import { useState, useRef, useEffect } from "react";
import { Editor } from "@monaco-editor/react";

interface MultiLanguagePlaygroundProps {
  language: string;
  template?: string;
  onCodeChange?: (code: string) => void;
}

export function MultiLanguagePlayground({ 
  language, 
  template = "", 
  onCodeChange 
}: MultiLanguagePlaygroundProps) {
  const [code, setCode] = useState(template);
  const [output, setOutput] = useState("");
  const [isRunning, setIsRunning] = useState(false);
  const [pyodideReady, setPyodideReady] = useState(false);
  const pyodideRef = useRef<any>(null);
  const iframeRef = useRef<HTMLIFrameElement>(null);

  // Initialize Pyodide for Python
  useEffect(() => {
    if (language === "python" && !pyodideRef.current) {
      const loadPyodide = async () => {
        try {
          // @ts-ignore - Pyodide is loaded via CDN
          const pyodide = await window.loadPyodide({
            indexURL: "https://cdn.jsdelivr.net/pyodide/v0.24.1/full/"
          });
          pyodideRef.current = pyodide;
          setPyodideReady(true);
          setOutput("Python ready! 🐍 Try running some code ^_^");
        } catch (error) {
          setOutput("Failed to load Python environment >_<");
        }
      };
      loadPyodide();
    }
  }, [language]);

  const handleCodeChange = (value: string | undefined) => {
    const newCode = value || "";
    setCode(newCode);
    onCodeChange?.(newCode);
    
    // Live preview for HTML
    if ((language === "html" || language === "html-css") && iframeRef.current) {
      const doc = iframeRef.current.contentDocument;
      if (doc) {
        doc.open();
        doc.write(newCode);
        doc.close();
      }
    }
  };

  const runCode = async () => {
    setIsRunning(true);
    setOutput("Running... ⚡");

    try {
      let result = "";

      switch (language) {
        case "python":
          result = await runPython(code);
          break;
        case "javascript":
          result = runJavaScript(code);
          break;
        case "html":
        case "html-css":
          result = "HTML preview updated! Check the preview panel 🎨";
          break;
        case "c":
        case "cpp":
          result = await runCppOnline(code, language);
          break;
        default:
          result = `${language.toUpperCase()} execution not implemented yet (•_•)`;
      }

      setOutput(result);
    } catch (error) {
      setOutput(`Error: ${error}\n\nDon't worry, debugging is part of learning! 💪`);
    } finally {
      setIsRunning(false);
    }
  };

  const runPython = async (pythonCode: string): Promise<string> => {
    if (!pyodideRef.current) {
      return "Python environment not ready yet! Please wait a moment ^_^";
    }

    try {
      // Capture stdout
      pyodideRef.current.runPython(`
import sys
from io import StringIO
sys.stdout = StringIO()
      `);

      // Run user code
      pyodideRef.current.runPython(pythonCode);

      // Get output
      const stdout = pyodideRef.current.runPython("sys.stdout.getvalue()");
      return stdout || "Code executed successfully! ^_^\n(No output to display)";
    } catch (error: any) {
      // Enhanced error messages with emotes
      const errorMsg = error.toString();
      if (errorMsg.includes('SyntaxError')) {
        return `Syntax Error! Check your indentation and colons ^_^\n\n${errorMsg}`;
      } else if (errorMsg.includes('NameError')) {
        return `Name Error! Did you define that variable? (•_•)\n\n${errorMsg}`;
      } else if (errorMsg.includes('TypeError')) {
        return `Type Error! Check your data types >_<\n\n${errorMsg}`;
      } else {
        return `Python Error: ${errorMsg}\n\nDon't worry, debugging is part of learning! 💪`;
      }
    }
  };

  const runJavaScript = (jsCode: string): string => {
    const logs: string[] = [];
    const originalLog = console.log;
    const originalError = console.error;

    // Override console methods
    console.log = (...args) => {
      logs.push(args.map(arg => String(arg)).join(' '));
    };
    console.error = (...args) => {
      logs.push(`Error: ${args.map(arg => String(arg)).join(' ')}`);
    };

    try {
      // Create a safe evaluation context
      const result = new Function(jsCode)();
      if (result !== undefined) {
        logs.push(`Return value: ${result}`);
      }
    } catch (error: any) {
      const errorMsg = error.toString();
      if (errorMsg.includes('SyntaxError')) {
        logs.push(`Syntax Error! Check your brackets and semicolons ^_^\n${errorMsg}`);
      } else if (errorMsg.includes('ReferenceError')) {
        logs.push(`Reference Error! Variable not defined? (•_•)\n${errorMsg}`);
      } else {
        logs.push(`JavaScript Error: ${errorMsg}`);
      }
    } finally {
      // Restore console methods
      console.log = originalLog;
      console.error = originalError;
    }

    return logs.join('\n') || "Code executed successfully! ⚡\n(No output to display)";
  };

  const runCppOnline = async (cppCode: string, lang: string): Promise<string> => {
    try {
      // Use Compiler Explorer API (godbolt.org)
      const compiler = lang === "c" ? "cclang1600" : "clang1600";
      const response = await fetch("https://godbolt.org/api/compiler/" + compiler + "/compile", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({
          source: cppCode,
          options: {
            userArguments: "",
            executeParameters: {
              args: [],
              stdin: ""
            },
            compilerOptions: {
              executorRequest: true
            },
            filters: {
              execute: true
            }
          }
        })
      });

      if (!response.ok) {
        throw new Error("Compilation service unavailable");
      }

      const data = await response.json();
      
      if (data.execResult) {
        const { stdout, stderr, code: exitCode } = data.execResult;
        let result = "";
        
        if (stdout && stdout.length > 0) {
          result += "Output:\n" + stdout.map((line: any) => line.text).join('\n');
        }
        
        if (stderr && stderr.length > 0) {
          result += "\nErrors:\n" + stderr.map((line: any) => line.text).join('\n');
        }
        
        if (exitCode !== 0) {
          result += `\nProgram exited with code: ${exitCode}`;
        }
        
        return result || "Program compiled and ran successfully! 🎯";
      } else {
        return "Compilation failed. Check your syntax! (•_•)";
      }
    } catch (error: any) {
      return `Compilation Error: ${error}\n\nTips for ${lang.toUpperCase()}:\n• Make sure you have a main() function\n• Include necessary headers (stdio.h for C, iostream for C++)\n• Check your syntax and semicolons! (•_•)`;
    }
  };

  const resetCode = () => {
    setCode(template);
    setOutput("");
    if ((language === "html" || language === "html-css") && iframeRef.current) {
      const doc = iframeRef.current.contentDocument;
      if (doc) {
        doc.open();
        doc.write(template);
        doc.close();
      }
    }
  };

  const getLanguageMode = (lang: string) => {
    const modes: Record<string, string> = {
      python: "python",
      javascript: "javascript", 
      html: "html",
      "html-css": "html",
      c: "c",
      cpp: "cpp"
    };
    return modes[lang] || "plaintext";
  };

  const getFileExtension = (lang: string) => {
    const extensions: Record<string, string> = {
      python: "py",
      javascript: "js",
      html: "html",
      "html-css": "html",
      c: "c",
      cpp: "cpp"
    };
    return extensions[lang] || "txt";
  };

  return (
    <div className="p-6">
      {/* Pyodide loading script */}
      {language === "python" && (
        <script src="https://cdn.jsdelivr.net/pyodide/v0.24.1/full/pyodide.js" async />
      )}
      
      <div className="flex items-center justify-between mb-4">
        <h3 className="text-xl font-bold text-gray-800 dark:text-white">
          {language.charAt(0).toUpperCase() + language.slice(1)} Playground 🎮
        </h3>
        <div className="flex gap-2">
          <button
            onClick={resetCode}
            className="px-4 py-2 bg-gray-200 dark:bg-gray-700 text-gray-700 dark:text-gray-300 rounded-lg hover:bg-gray-300 dark:hover:bg-gray-600 transition-colors text-sm"
          >
            Reset
          </button>
          <button
            onClick={runCode}
            disabled={isRunning || (language === "python" && !pyodideReady)}
            className="px-6 py-2 bg-gradient-to-r from-green-500 to-blue-500 text-white rounded-lg font-semibold hover:shadow-lg transition-all duration-300 disabled:opacity-50 disabled:cursor-not-allowed"
          >
            {isRunning ? "Running..." : "Run Code ▶️"}
          </button>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Code Editor */}
        <div>
          <div className="bg-gray-100 dark:bg-gray-900 rounded-lg p-1 mb-2">
            <div className="bg-gray-800 text-gray-300 px-3 py-2 rounded-t text-sm font-mono">
              {language}.{getFileExtension(language)} - Editor
            </div>
          </div>
          <div className="border border-gray-300 dark:border-gray-600 rounded-b-lg overflow-hidden">
            <Editor
              height="320px"
              language={getLanguageMode(language)}
              value={code}
              onChange={handleCodeChange}
              theme="vs-dark"
              options={{
                minimap: { enabled: false },
                fontSize: 14,
                lineNumbers: "on",
                roundedSelection: false,
                scrollBeyondLastLine: false,
                automaticLayout: true,
                tabSize: 2,
                insertSpaces: true,
                wordWrap: "on"
              }}
            />
          </div>
        </div>

        {/* Output/Preview */}
        <div>
          <div className="bg-gray-100 dark:bg-gray-900 rounded-lg p-1 mb-2">
            <div className="bg-gray-800 text-gray-300 px-3 py-2 rounded-t text-sm font-mono">
              {(language === "html" || language === "html-css") ? "Live Preview" : "Output"} 📺
            </div>
          </div>
          {(language === "html" || language === "html-css") ? (
            <iframe
              ref={iframeRef}
              className="w-full h-80 bg-white rounded-b-lg border border-gray-300 dark:border-gray-600"
              title="HTML Preview"
              sandbox="allow-scripts"
              srcDoc={code}
            />
          ) : (
            <div className="w-full h-80 p-4 bg-gray-900 text-gray-300 font-mono text-sm rounded-b-lg border border-gray-300 dark:border-gray-600 overflow-auto whitespace-pre-wrap">
              {output || "Click 'Run Code' to see output here! (•_•)"}
            </div>
          )}
        </div>
      </div>

      {/* Language-specific tips */}
      <div className="mt-6 p-4 bg-blue-50 dark:bg-blue-900/20 rounded-lg">
        <h4 className="font-semibold text-blue-800 dark:text-blue-300 mb-2">
          💡 Tips for {language}:
        </h4>
        <div className="text-sm text-blue-700 dark:text-blue-300">
          {getLanguageTips(language)}
        </div>
      </div>

      {/* Status indicators */}
      {language === "python" && (
        <div className="mt-4 text-center">
          <div className={`inline-block px-3 py-1 rounded-full text-xs ${
            pyodideReady 
              ? "bg-green-100 dark:bg-green-900 text-green-800 dark:text-green-200"
              : "bg-yellow-100 dark:bg-yellow-900 text-yellow-800 dark:text-yellow-200"
          }`}>
            Python Environment: {pyodideReady ? "Ready! 🐍" : "Loading... ⏳"}
          </div>
        </div>
      )}
    </div>
  );
}

function getLanguageTips(language: string): string {
  const tips: Record<string, string> = {
    python: "• Use print() to see output • Variables don't need declaration • Indentation matters! • Try f-strings: f'Hello {name}' • Full Python stdlib available!",
    javascript: "• Use console.log() for output • Declare with let/const • Template literals: `Hello ${name}` • Semicolons optional but good practice",
    html: "• Every tag should close • Use proper nesting • Add alt text to images • Preview updates live as you type!",
    c: "• Include headers with #include <stdio.h> • Every program needs main() • Don't forget semicolons • printf() for output",
    cpp: "• Include <iostream> • Use std::cout for output • Every program needs main() • Don't forget using namespace std; or std:: prefix"
  };
  return tips[language] || "• Experiment and have fun! • Read error messages carefully • Practice makes perfect ^_^";
}
