import { useState } from "react";
import { useMutation, useQuery } from "convex/react";
import { api } from "../../convex/_generated/api";

interface FlashcardData {
  front: string;
  back: string;
}

interface FlashcardsProps {
  cards: FlashcardData[];
  lessonId: string;
}

export function Flashcards({ cards, lessonId }: FlashcardsProps) {
  const [currentCard, setCurrentCard] = useState(0);
  const [isFlipped, setIsFlipped] = useState(false);
  const [studyMode, setStudyMode] = useState<"study" | "create">("study");
  const [newCardFront, setNewCardFront] = useState("");
  const [newCardBack, setNewCardBack] = useState("");

  const userFlashcards = useQuery(api.flashcards.getFlashcards, { lessonId });
  const createFlashcard = useMutation(api.flashcards.createFlashcard);
  const updateDifficulty = useMutation(api.flashcards.updateFlashcardDifficulty);

  const allCards = [...cards, ...(userFlashcards || [])];

  const handleFlip = () => {
    setIsFlipped(!isFlipped);
  };

  const handleNext = () => {
    setCurrentCard((prev) => (prev + 1) % allCards.length);
    setIsFlipped(false);
  };

  const handlePrevious = () => {
    setCurrentCard((prev) => (prev - 1 + allCards.length) % allCards.length);
    setIsFlipped(false);
  };

  const handleCreateCard = async () => {
    if (!newCardFront.trim() || !newCardBack.trim()) return;

    try {
      await createFlashcard({
        lessonId,
        front: newCardFront,
        back: newCardBack,
      });
      setNewCardFront("");
      setNewCardBack("");
      setStudyMode("study");
    } catch (error) {
      console.error("Failed to create flashcard:", error);
    }
  };

  const handleDifficulty = async (difficulty: number) => {
    const card = allCards[currentCard];
    if ('_id' in card && card._id) {
      try {
        await updateDifficulty({
          flashcardId: card._id as any,
          difficulty,
        });
      } catch (error) {
        console.error("Failed to update difficulty:", error);
      }
    }
  };

  if (allCards.length === 0) {
    return (
      <div className="p-8 text-center">
        <div className="text-6xl mb-4">🗃️</div>
        <h2 className="text-2xl font-bold text-gray-800 dark:text-white mb-4">
          No flashcards yet! (•_•)
        </h2>
        <p className="text-gray-600 dark:text-gray-300 mb-8">
          Create your first flashcard to start studying!
        </p>
        <button
          onClick={() => setStudyMode("create")}
          className="px-6 py-3 bg-gradient-to-r from-blue-500 to-green-500 text-white rounded-lg font-semibold hover:shadow-lg transition-all duration-300"
        >
          Create Flashcard ✨
        </button>
      </div>
    );
  }

  if (studyMode === "create") {
    return (
      <div className="p-8">
        <div className="max-w-2xl mx-auto">
          <div className="flex items-center justify-between mb-8">
            <h2 className="text-2xl font-bold text-gray-800 dark:text-white">
              Create New Flashcard ✨
            </h2>
            <button
              onClick={() => setStudyMode("study")}
              className="px-4 py-2 bg-gray-200 dark:bg-gray-700 text-gray-700 dark:text-gray-300 rounded-lg hover:bg-gray-300 dark:hover:bg-gray-600 transition-colors"
            >
              Back to Study
            </button>
          </div>

          <div className="space-y-6">
            <div>
              <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">
                Front (Question/Term) 🤔
              </label>
              <textarea
                value={newCardFront}
                onChange={(e) => setNewCardFront(e.target.value)}
                className="w-full p-4 border border-gray-300 dark:border-gray-600 rounded-lg bg-white dark:bg-gray-800 text-gray-800 dark:text-white focus:ring-2 focus:ring-blue-500 focus:border-transparent resize-none"
                rows={3}
                placeholder="What do you want to remember? ^_^"
              />
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">
                Back (Answer/Definition) 💡
              </label>
              <textarea
                value={newCardBack}
                onChange={(e) => setNewCardBack(e.target.value)}
                className="w-full p-4 border border-gray-300 dark:border-gray-600 rounded-lg bg-white dark:bg-gray-800 text-gray-800 dark:text-white focus:ring-2 focus:ring-blue-500 focus:border-transparent resize-none"
                rows={3}
                placeholder="The answer or explanation!"
              />
            </div>

            <button
              onClick={handleCreateCard}
              disabled={!newCardFront.trim() || !newCardBack.trim()}
              className="w-full py-3 bg-gradient-to-r from-blue-500 to-green-500 text-white rounded-lg font-semibold hover:shadow-lg transition-all duration-300 disabled:opacity-50 disabled:cursor-not-allowed"
            >
              Create Flashcard 🎯
            </button>
          </div>
        </div>
      </div>
    );
  }

  const card = allCards[currentCard];

  return (
    <div className="p-8">
      <div className="max-w-2xl mx-auto">
        <div className="flex items-center justify-between mb-8">
          <h2 className="text-2xl font-bold text-gray-800 dark:text-white">
            Flashcards 🗃️
          </h2>
          <div className="flex items-center gap-4">
            <span className="text-sm text-gray-600 dark:text-gray-400">
              {currentCard + 1} of {allCards.length}
            </span>
            <button
              onClick={() => setStudyMode("create")}
              className="px-4 py-2 bg-green-100 dark:bg-green-900 text-green-700 dark:text-green-300 rounded-lg hover:bg-green-200 dark:hover:bg-green-800 transition-colors text-sm"
            >
              + Add Card
            </button>
          </div>
        </div>

        {/* Flashcard */}
        <div className="relative mb-8">
          <div
            onClick={handleFlip}
            className={`w-full h-64 cursor-pointer transition-transform duration-500 transform-style-preserve-3d ${
              isFlipped ? 'rotate-y-180' : ''
            }`}
          >
            {/* Front */}
            <div className="absolute inset-0 w-full h-full backface-hidden bg-gradient-to-br from-blue-100 to-green-100 dark:from-blue-900 dark:to-green-900 rounded-xl shadow-lg border-2 border-blue-200 dark:border-blue-700 flex items-center justify-center p-6">
              <div className="text-center">
                <div className="text-sm text-blue-600 dark:text-blue-400 mb-2">Question</div>
                <div className="text-lg font-medium text-gray-800 dark:text-white">
                  {card.front}
                </div>
                <div className="text-sm text-gray-500 dark:text-gray-400 mt-4">
                  Click to flip! 🔄
                </div>
              </div>
            </div>

            {/* Back */}
            <div className="absolute inset-0 w-full h-full backface-hidden rotate-y-180 bg-gradient-to-br from-green-100 to-blue-100 dark:from-green-900 dark:to-blue-900 rounded-xl shadow-lg border-2 border-green-200 dark:border-green-700 flex items-center justify-center p-6">
              <div className="text-center">
                <div className="text-sm text-green-600 dark:text-green-400 mb-2">Answer</div>
                <div className="text-lg font-medium text-gray-800 dark:text-white">
                  {card.back}
                </div>
                <div className="text-sm text-gray-500 dark:text-gray-400 mt-4">
                  Got it? ^_^
                </div>
              </div>
            </div>
          </div>
        </div>

        {/* Navigation */}
        <div className="flex items-center justify-between mb-6">
          <button
            onClick={handlePrevious}
            className="px-4 py-2 bg-gray-200 dark:bg-gray-700 text-gray-700 dark:text-gray-300 rounded-lg hover:bg-gray-300 dark:hover:bg-gray-600 transition-colors"
          >
            ← Previous
          </button>
          
          <div className="flex gap-2">
            {allCards.map((_, index) => (
              <button
                key={index}
                onClick={() => {
                  setCurrentCard(index);
                  setIsFlipped(false);
                }}
                className={`w-3 h-3 rounded-full transition-colors ${
                  index === currentCard
                    ? 'bg-blue-500'
                    : 'bg-gray-300 dark:bg-gray-600 hover:bg-gray-400 dark:hover:bg-gray-500'
                }`}
              />
            ))}
          </div>

          <button
            onClick={handleNext}
            className="px-4 py-2 bg-gray-200 dark:bg-gray-700 text-gray-700 dark:text-gray-300 rounded-lg hover:bg-gray-300 dark:hover:bg-gray-600 transition-colors"
          >
            Next →
          </button>
        </div>

        {/* Difficulty rating (for user-created cards) */}
        {isFlipped && '_id' in card && (
          <div className="text-center">
            <p className="text-sm text-gray-600 dark:text-gray-400 mb-3">
              How difficult was this? (•_•)
            </p>
            <div className="flex justify-center gap-2">
              {[1, 2, 3, 4, 5].map((level) => (
                <button
                  key={level}
                  onClick={() => handleDifficulty(level)}
                  className="px-3 py-1 text-sm bg-gray-100 dark:bg-gray-800 text-gray-700 dark:text-gray-300 rounded hover:bg-gray-200 dark:hover:bg-gray-700 transition-colors"
                >
                  {level === 1 ? 'Easy 😊' : level === 5 ? 'Hard 😅' : level}
                </button>
              ))}
            </div>
          </div>
        )}
      </div>
    </div>
  );
}
