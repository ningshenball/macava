import { useState, useEffect } from "react";
import { useMutation } from "convex/react";
import { api } from "../../convex/_generated/api";
import { MultiLanguagePlayground } from "./MultiLanguagePlayground";
import { Quiz } from "./Quiz";
import { Flashcards } from "./Flashcards";

interface LessonViewProps {
  language: string;
  lessonId: string;
  goHome: () => void;
}

const lessonContent = {
  python: {
    basics: {
      title: "Python Basics - Variables & Print",
      content: `Welcome to Python! /\\ 🐍

Python is like having a conversation with your computer. It's friendly and easy to understand!

## Variables - Your Data Containers 📦

Think of variables as labeled boxes where you store information:

\`\`\`python
name = "Coder"
age = 20
is_learning = True
\`\`\`

## The Print Function - Your Voice 📢

Use \`print()\` to display messages:

\`\`\`python
print("Hello, Macava! ^_^")
print("My name is", name)
print(f"I am {age} years old")
\`\`\`

Try it yourself in the playground below! 🎮`,
      starterCode: `# Welcome to Python! ^_^
print("Hello, Macava!")

# Create your first variables
name = "Your Name Here"
favorite_number = 42

# Print them out
print("My name is", name)
print("My favorite number is", favorite_number)

# Try f-strings (formatted strings)
print(f"Hi! I'm {name} and I love the number {favorite_number}!")`,
      quiz: [
        {
          question: "How do you create a variable in Python?",
          options: ["var name = 'value'", "name = 'value'", "let name = 'value'", "name := 'value'"],
          correct: 1
        },
        {
          question: "What does print() do?",
          options: ["Creates variables", "Displays output", "Deletes data", "Runs loops"],
          correct: 1
        },
        {
          question: "Which is a valid Python variable name?",
          options: ["2name", "my-name", "my_name", "my name"],
          correct: 2
        }
      ],
      flashcards: [
        { front: "What creates a variable in Python? ^_^", back: "variable_name = value" },
        { front: "How to display text?", back: "print('your text')" },
        { front: "What are f-strings?", back: "f'Hello {variable}' - formatted strings!" },
        { front: "Python file extension?", back: ".py" },
        { front: "Case sensitive?", back: "Yes! 'Name' ≠ 'name'" }
      ]
    }
  },
  javascript: {
    intro: {
      title: "JavaScript Intro - Console & Variables",
      content: `Welcome to JavaScript! /| ⚡

JavaScript brings websites to life with interactivity and dynamic behavior!

## Variables - Three Ways to Store Data 📦

\`\`\`javascript
let name = "Coder";        // Can change
const age = 20;           // Cannot change  
var oldStyle = "avoid";   // Old way, avoid
\`\`\`

## Console.log - Your Debug Friend 🔍

Use \`console.log()\` to see what's happening:

\`\`\`javascript
console.log("Zap! ⚡");
console.log("Name:", name);
console.log(\`I am \${age} years old\`);
\`\`\`

## Template Literals - Modern Strings ✨

Use backticks for powerful string formatting:

\`\`\`javascript
const greeting = \`Hello, \${name}! Welcome to JavaScript!\`;
\`\`\`

Ready to zap some code? ⚡`,
      starterCode: `// Welcome to JavaScript! ⚡
console.log("Zap! Welcome to JS!");

// Create variables
let userName = "Coder";
const favoriteLanguage = "JavaScript";
let experienceLevel = "Beginner";

// Log them out
console.log("User:", userName);
console.log("Favorite Language:", favoriteLanguage);

// Template literals with backticks
console.log(\`Hi \${userName}! You're learning \${favoriteLanguage}!\`);

// Try changing experienceLevel and run again!
experienceLevel = "Intermediate";
console.log(\`New level: \${experienceLevel}\`);`,
      quiz: [
        {
          question: "Which keyword creates a changeable variable?",
          options: ["const", "let", "var", "variable"],
          correct: 1
        },
        {
          question: "How do you display output in JavaScript?",
          options: ["print()", "console.log()", "alert()", "display()"],
          correct: 1
        },
        {
          question: "What are template literals wrapped in?",
          options: ["Single quotes", "Double quotes", "Backticks", "Parentheses"],
          correct: 2
        }
      ],
      flashcards: [
        { front: "Changeable variable keyword?", back: "let variableName = value" },
        { front: "Unchangeable variable?", back: "const CONSTANT = value" },
        { front: "Display in console?", back: "console.log('message')" },
        { front: "Template literal syntax?", back: "`Hello ${variable}`" },
        { front: "JS file extension?", back: ".js" }
      ]
    }
  },
  html: {
    structure: {
      title: "HTML Structure - Tags & Elements",
      content: `Welcome to HTML! [] 🎨

HTML is the skeleton of every webpage. It gives structure and meaning to content!

## Basic Structure 🏗️

Every HTML page has this basic structure:

\`\`\`html
<!DOCTYPE html>
<html>
<head>
    <title>My Page</title>
</head>
<body>
    <h1>Welcome!</h1>
    <p>This is a paragraph.</p>
</body>
</html>
\`\`\`

## Common Tags 🏷️

- \`<h1>\` to \`<h6>\` - Headings (biggest to smallest)
- \`<p>\` - Paragraphs
- \`<div>\` - Containers
- \`<span>\` - Inline containers
- \`<a href="url">\` - Links
- \`<img src="image.jpg">\` - Images

## Attributes ⚙️

Tags can have attributes for extra information:

\`\`\`html
<a href="https://macava.io" target="_blank">Visit Macava!</a>
<img src="logo.png" alt="Macava Logo" width="100">
\`\`\`

Let's build your first webpage! 🚀`,
      starterCode: `<!DOCTYPE html>
<html>
<head>
    <title>My First Macava Page! ^_^</title>
</head>
<body>
    <h1>Welcome to My Page!</h1>
    <h2>About Me</h2>
    <p>Hi! I'm learning HTML on Macava.io and it's awesome!</p>
    
    <h2>My Favorite Things</h2>
    <ul>
        <li>Coding</li>
        <li>Learning new things</li>
        <li>Building websites</li>
    </ul>
    
    <p>Check out <a href="https://macava.io">Macava.io</a> for more lessons!</p>
    
    <div>
        <p><strong>Fun fact:</strong> This is my first HTML page! 🎉</p>
    </div>
</body>
</html>`,
      quiz: [
        {
          question: "What does HTML stand for?",
          options: ["Hyper Text Markup Language", "High Tech Modern Language", "Home Tool Markup Language", "Hyper Transfer Markup Language"],
          correct: 0
        },
        {
          question: "Which tag creates the largest heading?",
          options: ["<h6>", "<h3>", "<h1>", "<header>"],
          correct: 2
        },
        {
          question: "What attribute specifies a link's destination?",
          options: ["src", "href", "link", "url"],
          correct: 1
        }
      ],
      flashcards: [
        { front: "HTML document structure?", back: "<!DOCTYPE html><html><head></head><body></body></html>" },
        { front: "Largest heading tag?", back: "<h1>Heading</h1>" },
        { front: "Paragraph tag?", back: "<p>Text here</p>" },
        { front: "Link with href?", back: "<a href='url'>Link text</a>" },
        { front: "Image tag?", back: "<img src='image.jpg' alt='description'>" }
      ]
    }
  }
};

export function LessonView({ language, lessonId, goHome }: LessonViewProps) {
  const [currentSection, setCurrentSection] = useState<"content" | "playground" | "quiz" | "flashcards">("content");
  const [quizScore, setQuizScore] = useState<number | null>(null);
  const completeLesson = useMutation(api.progress.completeLesson);

  const lesson = lessonContent[language as keyof typeof lessonContent]?.[lessonId as keyof typeof lessonContent[keyof typeof lessonContent]] as any;

  if (!lesson) {
    return (
      <div className="max-w-4xl mx-auto text-center">
        <h1 className="text-3xl font-bold text-gray-800 dark:text-white mb-4">
          Lesson Not Found {'>_<'}
        </h1>
        <p className="text-gray-600 dark:text-gray-300 mb-8">
          This lesson is still being prepared! Check back soon ^_^
        </p>
        <button
          onClick={goHome}
          className="px-6 py-3 bg-gradient-to-r from-blue-500 to-green-500 text-white rounded-lg font-semibold hover:shadow-lg transition-all duration-300"
        >
          Back to Home
        </button>
      </div>
    );
  }

  const handleQuizComplete = async (score: number) => {
    setQuizScore(score);
    try {
      await completeLesson({ language, lessonId, score });
    } catch (error) {
      console.error("Failed to save progress:", error);
    }
  };

  return (
    <div className="max-w-6xl mx-auto">
      {/* Header */}
      <div className="flex items-center justify-between mb-8">
        <div>
          <h1 className="text-3xl md:text-4xl font-bold text-gray-800 dark:text-white mb-2">
            {lesson.title}
          </h1>
          <p className="text-gray-600 dark:text-gray-300">
            Let's learn together! ^_^
          </p>
        </div>
        <button
          onClick={goHome}
          className="px-4 py-2 bg-gray-200 dark:bg-gray-700 text-gray-700 dark:text-gray-300 rounded-lg hover:bg-gray-300 dark:hover:bg-gray-600 transition-colors"
        >
          ← Back
        </button>
      </div>

      {/* Navigation */}
      <div className="flex flex-wrap gap-2 mb-8">
        <SectionButton
          active={currentSection === "content"}
          onClick={() => setCurrentSection("content")}
          emoji="📖"
        >
          Learn
        </SectionButton>
        <SectionButton
          active={currentSection === "playground"}
          onClick={() => setCurrentSection("playground")}
          emoji="🎮"
        >
          Practice
        </SectionButton>
        <SectionButton
          active={currentSection === "quiz"}
          onClick={() => setCurrentSection("quiz")}
          emoji=":D"
        >
          Quiz
        </SectionButton>
        <SectionButton
          active={currentSection === "flashcards"}
          onClick={() => setCurrentSection("flashcards")}
          emoji="🗃️"
        >
          Flashcards
        </SectionButton>
      </div>

      {/* Content */}
      <div className="bg-white dark:bg-gray-800 rounded-2xl shadow-xl overflow-hidden">
        {currentSection === "content" && (
          <div className="p-8">
            <div className="prose prose-lg dark:prose-invert max-w-none">
              <div dangerouslySetInnerHTML={{ __html: formatContent(lesson.content) }} />
            </div>
            <div className="mt-8 text-center">
              <button
                onClick={() => setCurrentSection("playground")}
                className="px-6 py-3 bg-gradient-to-r from-blue-500 to-green-500 text-white rounded-lg font-semibold hover:shadow-lg transition-all duration-300"
              >
                Try it in Playground! 🎮
              </button>
            </div>
          </div>
        )}

        {currentSection === "playground" && (
          <MultiLanguagePlayground
            language={language}
            template={lesson.starterCode}
          />
        )}

        {currentSection === "quiz" && (
          <Quiz
            questions={lesson.quiz}
            onComplete={handleQuizComplete}
            currentScore={quizScore}
          />
        )}

        {currentSection === "flashcards" && (
          <Flashcards
            cards={lesson.flashcards}
            lessonId={lessonId}
          />
        )}
      </div>

      {/* Progress indicator */}
      {quizScore !== null && (
        <div className="mt-8 text-center">
          <div className={`inline-block px-6 py-3 rounded-xl ${
            quizScore >= 80 
              ? "bg-green-100 dark:bg-green-900 text-green-800 dark:text-green-200" 
              : "bg-yellow-100 dark:bg-yellow-900 text-yellow-800 dark:text-yellow-200"
          }`}>
            {quizScore >= 80 ? (
              <>🎉 Lesson completed! Score: {quizScore}% \\o/</>
            ) : (
              <>Keep practicing! Score: {quizScore}% - You can do it! ^_^</>
            )}
          </div>
        </div>
      )}
    </div>
  );
}

function SectionButton({ 
  children, 
  active, 
  onClick, 
  emoji 
}: { 
  children: React.ReactNode; 
  active: boolean; 
  onClick: () => void; 
  emoji: string; 
}) {
  return (
    <button
      onClick={onClick}
      className={`px-4 py-2 rounded-lg font-medium transition-all duration-200 ${
        active
          ? "bg-gradient-to-r from-blue-500 to-green-500 text-white shadow-lg"
          : "bg-gray-100 dark:bg-gray-700 text-gray-700 dark:text-gray-300 hover:bg-gray-200 dark:hover:bg-gray-600"
      }`}
    >
      <span className="mr-2">{emoji}</span>
      {children}
    </button>
  );
}

function formatContent(content: string): string {
  return content
    .replace(/## (.*)/g, '<h2 class="text-2xl font-bold mt-8 mb-4 text-gray-800 dark:text-white">$1</h2>')
    .replace(/```(\w+)?\n([\s\S]*?)```/g, '<pre class="bg-gray-100 dark:bg-gray-900 rounded-lg p-4 my-4 overflow-x-auto"><code class="text-sm">$2</code></pre>')
    .replace(/`([^`]+)`/g, '<code class="bg-gray-100 dark:bg-gray-800 px-2 py-1 rounded text-sm">$1</code>')
    .replace(/\n\n/g, '</p><p class="mb-4">')
    .replace(/^(.*)$/gm, '<p class="mb-4">$1</p>')
    .replace(/<p class="mb-4"><\/p>/g, '');
}
