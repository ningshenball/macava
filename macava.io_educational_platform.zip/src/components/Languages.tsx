import { useState } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { BasicConcepts } from "./BasicConcepts";

interface LanguagesProps {
  startLesson: (language: string, lessonId: string) => void;
}

const languages = [
  {
    id: "python",
    name: "Python",
    emoji: "/\\",
    icon: "🐍",
    tagline: "Easy as pie! :-D",
    description: "Start with the friendliest programming language",
    color: "from-green-400 to-blue-500",
    lessons: ["basics", "loops", "functions", "lists"]
  },
  {
    id: "c",
    name: "C",
    emoji: "[O]",
    icon: "⚙️",
    tagline: "Gear up!",
    description: "Master the foundation of programming",
    color: "from-gray-400 to-gray-600",
    lessons: ["intro", "variables", "functions", "pointers"]
  },
  {
    id: "cpp",
    name: "C++",
    emoji: "O->",
    icon: "🔄",
    tagline: "Level up!",
    description: "Object-oriented programming power",
    color: "from-blue-400 to-purple-500",
    lessons: ["basics", "classes", "inheritance", "templates"]
  },
  {
    id: "javascript",
    name: "JavaScript",
    emoji: "/|",
    icon: "⚡",
    tagline: "Zap it!",
    description: "Bring websites to life with interactivity",
    color: "from-yellow-400 to-orange-500",
    lessons: ["intro", "dom", "events", "async"]
  },
  {
    id: "html-css",
    name: "HTML & CSS",
    emoji: "[]",
    icon: "🎨",
    tagline: "Style it!",
    description: "Create beautiful web pages",
    color: "from-pink-400 to-red-500",
    lessons: ["structure", "styling", "layout", "responsive"]
  }
];

export function Languages({ startLesson }: LanguagesProps) {
  const [selectedLanguage, setSelectedLanguage] = useState<string | null>(null);
  const [viewMode, setViewMode] = useState<"overview" | "concepts">("overview");
  
  if (selectedLanguage && viewMode === "concepts") {
    return (
      <motion.div
        initial={{ opacity: 0, x: 20 }}
        animate={{ opacity: 1, x: 0 }}
        exit={{ opacity: 0, x: -20 }}
        transition={{ duration: 0.3 }}
      >
        <div className="flex items-center justify-between mb-8">
          <h1 className="text-3xl font-bold text-gray-800 dark:text-white">
            {languages.find(l => l.id === selectedLanguage)?.name} Concepts
          </h1>
          <button
            onClick={() => {
              setSelectedLanguage(null);
              setViewMode("overview");
            }}
            className="px-4 py-2 bg-gray-200 dark:bg-gray-700 text-gray-700 dark:text-gray-300 rounded-lg hover:bg-gray-300 dark:hover:bg-gray-600 transition-colors"
          >
            ← Back to Languages
          </button>
        </div>
        <BasicConcepts language={selectedLanguage} />
      </motion.div>
    );
  }
  
  return (
    <div className="max-w-6xl mx-auto">
      <div className="text-center mb-12">
        <h1 className="text-4xl md:text-5xl font-bold text-gray-800 dark:text-white mb-4">
          Choose Your Adventure! 🚀
        </h1>
        <p className="text-xl text-gray-600 dark:text-gray-300">
          Pick a language and start your coding journey ^_^
        </p>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
        {languages.map((lang) => (
          <LanguageCard
            key={lang.id}
            language={lang}
            onStartLesson={(lessonId) => startLesson(lang.id, lessonId)}
            onViewConcepts={() => {
              setSelectedLanguage(lang.id);
              setViewMode("concepts");
            }}
          />
        ))}
      </div>

      {/* ASCII Border */}
      <div className="text-center text-gray-400 dark:text-gray-600 font-mono text-sm mt-12">
        ─────────────────────────────────────────────────────────
      </div>
    </div>
  );
}

function LanguageCard({ 
  language, 
  onStartLesson,
  onViewConcepts
}: { 
  language: typeof languages[0]; 
  onStartLesson: (lessonId: string) => void;
  onViewConcepts: () => void;
}) {
  return (
    <div className="bg-white dark:bg-gray-800 rounded-2xl shadow-xl overflow-hidden hover:shadow-2xl transition-all duration-300 hover:scale-105">
      {/* Header */}
      <div className={`bg-gradient-to-r ${language.color} p-6 text-white`}>
        <div className="flex items-center justify-between mb-2">
          <span className="font-mono text-2xl">{language.emoji}</span>
          <span className="text-3xl">{language.icon}</span>
        </div>
        <h3 className="text-2xl font-bold mb-1">{language.name}</h3>
        <p className="text-lg opacity-90">{language.tagline}</p>
      </div>

      {/* Content */}
      <div className="p-6">
        <p className="text-gray-600 dark:text-gray-300 mb-6">
          {language.description}
        </p>

        {/* Sample Code */}
        <div className="bg-gray-100 dark:bg-gray-900 rounded-lg p-4 mb-6 font-mono text-sm">
          <CodeSample language={language.id} />
        </div>

        {/* Lessons */}
        <div className="space-y-2 mb-6">
          <h4 className="font-semibold text-gray-800 dark:text-white">Lessons:</h4>
          {language.lessons.map((lesson, index) => (
            <button
              key={lesson}
              onClick={() => onStartLesson(lesson)}
              className="w-full text-left px-3 py-2 rounded-lg bg-gray-50 dark:bg-gray-700 hover:bg-gray-100 dark:hover:bg-gray-600 transition-colors text-sm"
            >
              {index + 1}. {lesson.charAt(0).toUpperCase() + lesson.slice(1)}
            </button>
          ))}
        </div>

        {/* Action Buttons */}
        <div className="space-y-3">
          <button
            onClick={onViewConcepts}
            className="w-full py-2 rounded-lg font-medium text-gray-700 dark:text-gray-300 bg-gray-100 dark:bg-gray-700 hover:bg-gray-200 dark:hover:bg-gray-600 transition-all duration-300"
          >
            📚 View Concepts
          </button>
          <button
            onClick={() => onStartLesson(language.lessons[0])}
            className={`w-full py-3 rounded-lg font-semibold text-white bg-gradient-to-r ${language.color} hover:shadow-lg transition-all duration-300 hover:scale-105`}
          >
            Start Learning! 🎯
          </button>
        </div>
      </div>
    </div>
  );
}

function CodeSample({ language }: { language: string }) {
  const samples = {
    python: `print("Hello, Macava! ^_^")
name = "Coder"
print(f"Welcome, {name}!")`,
    c: `#include <stdio.h>
int main() {
    printf("Hello, World!");
    return 0;
}`,
    cpp: `#include <iostream>
using namespace std;
int main() {
    cout << "Hello, C++!";
    return 0;
}`,
    javascript: `console.log("Zap! ⚡");
let greeting = "Hello, JS!";
alert(greeting);`,
    "html-css": `<div class="card">
  <h1>Hello, Web!</h1>
  <p>Style me! 🎨</p>
</div>`
  };

  return (
    <div className="text-gray-800 dark:text-gray-200">
      {samples[language as keyof typeof samples]?.split('\n').map((line, i) => (
        <div key={i} className="animate-typewriter" style={{ animationDelay: `${i * 0.1}s` }}>
          {line}
        </div>
      ))}
    </div>
  );
}
