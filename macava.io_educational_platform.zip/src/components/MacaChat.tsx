import { useState, useRef, useEffect } from "react";
import { useAction, useQuery } from "convex/react";
import { api } from "../../convex/_generated/api";

export function MacaChat() {
  const [isOpen, setIsOpen] = useState(false);
  const [message, setMessage] = useState("");
  const chatHistory = useQuery(api.chat.getChatHistory) || [];
  const chatWithMaca = useAction(api.chat.chatWithMaca);
  const [isSending, setIsSending] = useState(false);
  const chatEndRef = useRef<HTMLDivElement | null>(null);

  const toggleChat = () => setIsOpen(!isOpen);

  const scrollToBottom = () => {
    chatEndRef.current?.scrollIntoView({ behavior: "smooth" });
  };

  useEffect(scrollToBottom, [chatHistory]);

  const handleSend = async () => {
    if (!message.trim()) return;
    setIsSending(true);
    setMessage("");
    try {
      await chatWithMaca({ message });
    } catch (error) {
      console.error("Failed to send message:", error);
    } finally {
      setIsSending(false);
    }
  };

  return (
    <>
      {/* Chat Bubble */}
      <button
        onClick={toggleChat}
        className="fixed bottom-6 right-6 w-16 h-16 bg-gradient-to-r from-blue-500 to-green-500 text-white rounded-full shadow-lg flex items-center justify-center text-3xl font-mono transform hover:scale-110 transition-transform"
        aria-label="Open chat"
      >
        {isOpen ? "x" : "<o_o>"}
      </button>

      {/* Chat Window */}
      {isOpen && (
        <div className="fixed bottom-24 right-6 w-80 h-[400px] bg-white dark:bg-gray-800 rounded-2xl shadow-2xl flex flex-col animate-slide-in">
          {/* Header */}
          <div className="p-4 bg-gradient-to-r from-blue-500 to-green-500 text-white rounded-t-2xl">
            <h3 className="font-bold text-lg text-center">Chat with Maca! ^_^</h3>
          </div>

          {/* Messages */}
          <div className="flex-1 p-4 overflow-y-auto">
            <div className="space-y-4">
              {chatHistory.slice().reverse().map((chat, index) => (
                <div key={index}>
                  <div className="flex justify-end">
                    <div className="bg-blue-500 text-white p-2 rounded-lg max-w-[80%]">
                      {chat.message}
                    </div>
                  </div>
                  <div className="flex justify-start mt-2">
                    <div className="bg-gray-200 dark:bg-gray-700 p-2 rounded-lg max-w-[80%]">
                      {chat.response}
                    </div>
                  </div>
                </div>
              ))}
              {isSending && (
                <div className="flex justify-start">
                  <div className="bg-gray-200 dark:bg-gray-700 p-2 rounded-lg">
                    <div className="flex items-center">
                      <div className="w-2 h-2 bg-gray-500 rounded-full animate-bounce mr-1"></div>
                      <div className="w-2 h-2 bg-gray-500 rounded-full animate-bounce mr-1 delay-75"></div>
                      <div className="w-2 h-2 bg-gray-500 rounded-full animate-bounce delay-150"></div>
                    </div>
                  </div>
                </div>
              )}
              <div ref={chatEndRef} />
            </div>
          </div>

          {/* Input */}
          <div className="p-4 border-t border-gray-200 dark:border-gray-700">
            <div className="flex gap-2">
              <input
                type="text"
                value={message}
                onChange={(e) => setMessage(e.target.value)}
                onKeyPress={(e) => e.key === 'Enter' && handleSend()}
                placeholder="Ask me anything! :D"
                className="flex-1 px-3 py-2 rounded-lg border border-gray-300 dark:border-gray-600 bg-white dark:bg-gray-700 focus:outline-none focus:ring-2 focus:ring-blue-500"
                disabled={isSending}
              />
              <button
                onClick={handleSend}
                disabled={isSending || !message.trim()}
                className="px-4 py-2 bg-blue-500 text-white rounded-lg font-semibold hover:bg-blue-600 transition-colors disabled:opacity-50"
              >
                Send
              </button>
            </div>
          </div>
        </div>
      )}
    </>
  );
}
