import { defineSchema, defineTable } from "convex/server";
import { v } from "convex/values";
import { authTables } from "@convex-dev/auth/server";

const applicationTables = {
  userProgress: defineTable({
    userId: v.id("users"),
    language: v.string(),
    lessonId: v.string(),
    completed: v.boolean(),
    score: v.optional(v.number()),
    completedAt: v.optional(v.number()),
  }).index("by_user", ["userId"])
    .index("by_user_and_language", ["userId", "language"]),

  flashcards: defineTable({
    userId: v.id("users"),
    lessonId: v.string(),
    front: v.string(),
    back: v.string(),
    difficulty: v.number(), // 1-5 scale
    lastReviewed: v.optional(v.number()),
  }).index("by_user_and_lesson", ["userId", "lessonId"]),

  chatMessages: defineTable({
    userId: v.id("users"),
    message: v.string(),
    response: v.string(),
    timestamp: v.number(),
  }).index("by_user", ["userId"]),

  streaks: defineTable({
    userId: v.id("users"),
    currentStreak: v.number(),
    longestStreak: v.number(),
    lastActivity: v.number(),
  }).index("by_user", ["userId"]),
};

export default defineSchema({
  ...authTables,
  ...applicationTables,
});
