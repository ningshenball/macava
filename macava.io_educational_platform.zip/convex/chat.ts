import { action, query, internalMutation } from "./_generated/server";
import { v } from "convex/values";
import { getAuthUserId } from "@convex-dev/auth/server";
import OpenAI from "openai";
import { internal } from "./_generated/api";

// AI Provider configuration
type AIProvider = "openai" | "gemini" | "grok";
const AI_PROVIDER = (process.env.AI_PROVIDER || "openai") as AIProvider;

const openai = new OpenAI({
  baseURL: process.env.CONVEX_OPENAI_BASE_URL,
  apiKey: process.env.CONVEX_OPENAI_API_KEY,
});

export const getChatHistory = query({
  args: {},
  handler: async (ctx) => {
    const userId = await getAuthUserId(ctx);
    if (!userId) return [];

    return await ctx.db
      .query("chatMessages")
      .withIndex("by_user", (q) => q.eq("userId", userId))
      .order("desc")
      .take(20);
  },
});

export const getCurrentProvider = query({
  args: {},
  handler: async () => {
    return AI_PROVIDER;
  },
});

async function callAI(provider: AIProvider, systemPrompt: string, userMessage: string): Promise<string> {
  if (provider === "gemini") {
    const apiKey = process.env.GEMINI_API_KEY || "YOUR_GEMINI_KEY";
    const url = `https://generativelanguage.googleapis.com/v1beta/models/gemini-pro:generateContent?key=${apiKey}`;
    
    const response = await fetch(url, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        contents: [{
          parts: [{ text: `${systemPrompt}\n\nUser: ${userMessage}` }]
        }],
        generationConfig: {
          maxOutputTokens: 200,
          temperature: 0.7,
        }
      }),
    });

    if (!response.ok) {
      throw new Error(`Gemini API error: ${response.statusText}`);
    }

    const data = await response.json();
    return data.candidates?.[0]?.content?.parts?.[0]?.text || "I'm not sure how to respond to that! >_<";
  } 
  
  else if (provider === "grok") {
    const apiKey = process.env.GROK_API_KEY || "YOUR_GROK_KEY";
    const url = "https://api.x.ai/v1/chat/completions";
    
    const response = await fetch(url, {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        "Authorization": `Bearer ${apiKey}`,
      },
      body: JSON.stringify({
        model: "grok-beta",
        messages: [
          { role: "system", content: systemPrompt },
          { role: "user", content: userMessage },
        ],
        max_tokens: 200,
        temperature: 0.7,
      }),
    });

    if (!response.ok) {
      throw new Error(`Grok API error: ${response.statusText}`);
    }

    const data = await response.json();
    return data.choices?.[0]?.message?.content || "I'm not sure how to respond to that! >_<";
  }
  
  else {
    // Default to OpenAI (gpt-4o-mini or gpt-4.1-nano)
    const completion = await openai.chat.completions.create({
      model: "gpt-4o-mini",
      messages: [
        { role: "system", content: systemPrompt },
        { role: "user", content: userMessage },
      ],
      max_tokens: 200,
    });

    return completion.choices[0].message.content ?? "I'm not sure how to respond to that! >_<";
  }
}

export const chatWithMaca = action({
  args: { message: v.string() },
  handler: async (ctx, args) => {
    const userId = await getAuthUserId(ctx);
    if (!userId) throw new Error("Not authenticated");

    const systemPrompt = `You are Maca, a fun and encouraging CS study buddy on a platform called Macava.io.
Your goal is to help users learn programming concepts in a friendly and accessible way.
Always respond with enthusiasm and use ASCII emotes like ^_^, :D, \\o/, (•_•), and >_<.
Keep your answers concise (under 200 tokens) to be fast and cost-effective.
When relevant, provide very short, simple code examples.
Encourage users to try things out, for example, by suggesting a small exercise or a "mad libs" style challenge.
If you don't know an answer, respond with something like "That's a great question! I'm still learning about that myself. (•_•) Maybe try asking in a different way?"`;

    try {
      const response = await callAI(AI_PROVIDER, systemPrompt, args.message);

      // Save to chat history
      await ctx.runMutation(internal.chat.saveChatMessage, {
        message: args.message,
        response,
      });

      return response;
    } catch (error) {
      console.error("AI API error:", error);
      return "Oops! I'm having trouble thinking right now. (•_•) Try asking again in a moment!";
    }
  },
});

export const saveChatMessage = internalMutation({
  args: {
    message: v.string(),
    response: v.string(),
  },
  handler: async (ctx, args) => {
    const userId = await getAuthUserId(ctx);
    if (!userId) throw new Error("Not authenticated");

    await ctx.db.insert("chatMessages", {
      userId,
      message: args.message,
      response: args.response,
      timestamp: Date.now(),
    });
  },
});
