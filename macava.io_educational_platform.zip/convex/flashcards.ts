import { query, mutation } from "./_generated/server";
import { v } from "convex/values";
import { getAuthUserId } from "@convex-dev/auth/server";

export const getFlashcards = query({
  args: { lessonId: v.string() },
  handler: async (ctx, args) => {
    const userId = await getAuthUserId(ctx);
    if (!userId) return [];

    return await ctx.db
      .query("flashcards")
      .withIndex("by_user_and_lesson", (q) => 
        q.eq("userId", userId).eq("lessonId", args.lessonId)
      )
      .collect();
  },
});

export const createFlashcard = mutation({
  args: {
    lessonId: v.string(),
    front: v.string(),
    back: v.string(),
  },
  handler: async (ctx, args) => {
    const userId = await getAuthUserId(ctx);
    if (!userId) throw new Error("Not authenticated");

    return await ctx.db.insert("flashcards", {
      userId,
      lessonId: args.lessonId,
      front: args.front,
      back: args.back,
      difficulty: 3,
    });
  },
});

export const updateFlashcardDifficulty = mutation({
  args: {
    flashcardId: v.id("flashcards"),
    difficulty: v.number(),
  },
  handler: async (ctx, args) => {
    const userId = await getAuthUserId(ctx);
    if (!userId) throw new Error("Not authenticated");

    const flashcard = await ctx.db.get(args.flashcardId);
    if (!flashcard || flashcard.userId !== userId) {
      throw new Error("Flashcard not found");
    }

    await ctx.db.patch(args.flashcardId, {
      difficulty: args.difficulty,
      lastReviewed: Date.now(),
    });
  },
});
