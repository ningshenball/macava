import { query, mutation } from "./_generated/server";
import { v } from "convex/values";
import { getAuthUserId } from "@convex-dev/auth/server";

export const getUserProgress = query({
  args: {},
  handler: async (ctx) => {
    const userId = await getAuthUserId(ctx);
    if (!userId) return null;

    const progress = await ctx.db
      .query("userProgress")
      .withIndex("by_user", (q) => q.eq("userId", userId))
      .collect();

    const streak = await ctx.db
      .query("streaks")
      .withIndex("by_user", (q) => q.eq("userId", userId))
      .first();

    return {
      progress,
      streak: streak || { currentStreak: 0, longestStreak: 0 },
    };
  },
});

export const completeLesson = mutation({
  args: {
    language: v.string(),
    lessonId: v.string(),
    score: v.number(),
  },
  handler: async (ctx, args) => {
    const userId = await getAuthUserId(ctx);
    if (!userId) throw new Error("Not authenticated");

    // Update lesson progress
    const existing = await ctx.db
      .query("userProgress")
      .withIndex("by_user_and_language", (q) => 
        q.eq("userId", userId).eq("language", args.language)
      )
      .filter((q) => q.eq(q.field("lessonId"), args.lessonId))
      .first();

    if (existing) {
      await ctx.db.patch(existing._id, {
        completed: args.score >= 80,
        score: args.score,
        completedAt: Date.now(),
      });
    } else {
      await ctx.db.insert("userProgress", {
        userId,
        language: args.language,
        lessonId: args.lessonId,
        completed: args.score >= 80,
        score: args.score,
        completedAt: Date.now(),
      });
    }

    // Update streak
    const streak = await ctx.db
      .query("streaks")
      .withIndex("by_user", (q) => q.eq("userId", userId))
      .first();

    const now = Date.now();
    const today = new Date(now).toDateString();
    const lastActivity = streak?.lastActivity ? new Date(streak.lastActivity).toDateString() : null;

    if (streak) {
      const newStreak = lastActivity === today ? streak.currentStreak : 
                       lastActivity === new Date(now - 86400000).toDateString() ? streak.currentStreak + 1 : 1;
      
      await ctx.db.patch(streak._id, {
        currentStreak: newStreak,
        longestStreak: Math.max(streak.longestStreak, newStreak),
        lastActivity: now,
      });
    } else {
      await ctx.db.insert("streaks", {
        userId,
        currentStreak: 1,
        longestStreak: 1,
        lastActivity: now,
      });
    }

    return { success: true };
  },
});
